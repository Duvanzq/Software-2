package co.edu.unilibre.cafeteria.modelo;

/** Etapas del pedido, en orden. Solo se permite avanzar a la siguiente. */
public enum EstadoPedido {
    PENDIENTE("Pendiente"),
    EN_PREPARACION("En preparación"),
    LISTO("Listo"),
    ENTREGADO("Entregado");

    private final String etiqueta;

    EstadoPedido(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public EstadoPedido siguiente() {
        switch (this) {
            case PENDIENTE: return EN_PREPARACION;
            case EN_PREPARACION: return LISTO;
            case LISTO: return ENTREGADO;
            default: throw new IllegalStateException("El pedido ya fue entregado.");
        }
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
