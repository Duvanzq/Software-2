package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;

/** Línea inmutable del pedido: conserva nombre, descripción y precio al vender. */
public final class DetallePedido {
    private final String nombreProducto;
    private final String descripcion;
    private final BigDecimal precioUnitario;
    private final int cantidad;

    public DetallePedido(String nombreProducto, ItemMenu item, int cantidad) {
        if (nombreProducto == null || nombreProducto.trim().isEmpty()) {
            throw new IllegalArgumentException("El producto debe tener nombre.");
        }
        if (item == null) {
            throw new IllegalArgumentException("Debes seleccionar un producto.");
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        BigDecimal precio = item.getPrecio();
        if (precio == null || precio.signum() < 0) {
            throw new IllegalArgumentException("El precio del producto no puede ser negativo.");
        }
        String descripcionItem = item.getDescripcion();
        if (descripcionItem == null || descripcionItem.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía.");
        }
        this.nombreProducto = nombreProducto.trim();
        this.descripcion = descripcionItem;
        this.precioUnitario = precio;
        this.cantidad = cantidad;
    }

    public String getNombreProducto() { return nombreProducto; }
    public String getDescripcion() { return descripcion; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public int getCantidad() { return cantidad; }
    public BigDecimal getSubtotal() {
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }
}
