package co.edu.unilibre.cafeteria.promocion;

import java.math.BigDecimal;

/** Strategy: distintas formas de calcular un descuento. */
public interface PoliticaDescuento {
    BigDecimal calcularDescuento(BigDecimal subtotal);
    String describir();
}
