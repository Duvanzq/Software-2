package co.edu.unilibre.cafeteria.modelo;

import co.edu.unilibre.cafeteria.promocion.PoliticaDescuento;
import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

/** Promoción por días y horas; si cruza medianoche conserva el día de inicio. */
public final class Promocion {
    private final int id;
    private final String nombre;
    private final Set<DayOfWeek> dias;
    private final LocalTime inicio;
    private final LocalTime fin;
    private final PoliticaDescuento politica;
    private boolean activa = true;

    public Promocion(int id, String nombre, Set<DayOfWeek> dias, LocalTime inicio,
                     LocalTime fin, PoliticaDescuento politica) {
        if (id <= 0) throw new IllegalArgumentException("ID de promoción inválido.");
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("La promoción necesita nombre.");
        if (dias == null || dias.isEmpty() || dias.contains(null))
            throw new IllegalArgumentException("Elige al menos un día de la semana.");
        if (inicio == null || fin == null || inicio.equals(fin))
            throw new IllegalArgumentException("Las horas deben ser válidas y distintas.");
        if (politica == null) throw new IllegalArgumentException("Falta la regla de descuento.");
        this.id = id;
        this.nombre = nombre.trim();
        this.dias = Collections.unmodifiableSet(EnumSet.copyOf(dias));
        this.inicio = inicio;
        this.fin = fin;
        this.politica = politica;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public Set<DayOfWeek> getDias() { return dias; }
    public LocalTime getInicio() { return inicio; }
    public LocalTime getFin() { return fin; }
    public String getRegla() { return politica.describir(); }
    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }

    public boolean aplicaEn(LocalDateTime fechaHora) {
        if (fechaHora == null || !activa) return false;
        LocalTime hora = fechaHora.toLocalTime();
        DayOfWeek hoy = fechaHora.getDayOfWeek();
        if (inicio.isBefore(fin)) {
            return dias.contains(hoy) && !hora.isBefore(inicio) && hora.isBefore(fin);
        }
        // Ejemplo: promoción de viernes 22:00 a sábado 02:00.
        return (dias.contains(hoy) && !hora.isBefore(inicio))
                || (dias.contains(hoy.minus(1)) && hora.isBefore(fin));
    }

    public BigDecimal descuento(BigDecimal subtotal) {
        return politica.calcularDescuento(subtotal);
    }
}
