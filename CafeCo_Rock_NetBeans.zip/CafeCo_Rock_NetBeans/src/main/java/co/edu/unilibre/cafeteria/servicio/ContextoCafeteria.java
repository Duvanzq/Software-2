package co.edu.unilibre.cafeteria.servicio;

import java.time.Clock;

/** Servicios compartidos entre consola y Swing, sin duplicar lógica. */
public final class ContextoCafeteria {
    private final ProductoServicio productos;
    private final PromocionServicio promociones;
    private final PedidoServicio pedidos;
    private final CajaServicio caja;
    private final Clock reloj;

    public ContextoCafeteria() { this(Clock.systemDefaultZone()); }
    public ContextoCafeteria(Clock reloj) {
        if (reloj == null) throw new IllegalArgumentException("Se requiere reloj.");
        this.reloj = reloj;
        this.productos = new ProductoServicio();
        this.promociones = new PromocionServicio();
        this.pedidos = new PedidoServicio(promociones, reloj);
        this.caja = new CajaServicio(pedidos);
    }
    public ProductoServicio getProductos() { return productos; }
    public PromocionServicio getPromociones() { return promociones; }
    public PedidoServicio getPedidos() { return pedidos; }
    public CajaServicio getCaja() { return caja; }
    public Clock getReloj() { return reloj; }
}
