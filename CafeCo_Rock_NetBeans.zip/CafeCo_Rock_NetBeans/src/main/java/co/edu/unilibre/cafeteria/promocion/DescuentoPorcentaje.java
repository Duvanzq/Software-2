package co.edu.unilibre.cafeteria.promocion;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Porcentaje entre 1 y 100; se redondea al peso colombiano. */
public final class DescuentoPorcentaje implements PoliticaDescuento {
    private final BigDecimal porcentaje;

    public DescuentoPorcentaje(BigDecimal porcentaje) {
        if (porcentaje == null || porcentaje.signum() <= 0
                || porcentaje.compareTo(new BigDecimal("100")) > 0) {
            throw new IllegalArgumentException("El porcentaje debe ser mayor que cero y máximo 100.");
        }
        this.porcentaje = porcentaje;
    }

    @Override
    public BigDecimal calcularDescuento(BigDecimal subtotal) {
        validarSubtotal(subtotal);
        return subtotal.multiply(porcentaje)
                .divide(new BigDecimal("100"), 0, RoundingMode.HALF_UP).min(subtotal);
    }

    @Override
    public String describir() {
        return porcentaje.stripTrailingZeros().toPlainString() + "% de descuento";
    }

    static void validarSubtotal(BigDecimal subtotal) {
        if (subtotal == null || subtotal.signum() < 0) {
            throw new IllegalArgumentException("El subtotal no puede ser negativo ni nulo.");
        }
    }
}
