package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.EstadoPedido;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.modelo.ResumenCaja;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Consulta reproducible del cierre de caja por día de ENTREGA. */
public final class CajaServicio {
    private final PedidoServicio pedidos;

    public CajaServicio(PedidoServicio pedidos) {
        if (pedidos == null) throw new IllegalArgumentException("Servicio de pedidos requerido.");
        this.pedidos = pedidos;
    }

    public ResumenCaja resumir(LocalDate fecha) {
        if (fecha == null) throw new IllegalArgumentException("La fecha es obligatoria.");
        int cantidad = 0;
        BigDecimal bruto = BigDecimal.ZERO;
        BigDecimal descuento = BigDecimal.ZERO;
        BigDecimal neto = BigDecimal.ZERO;
        for (Pedido p : pedidos.listar()) {
            if (p.getEstado() == EstadoPedido.ENTREGADO
                    && p.getFechaEntrega() != null && fecha.equals(p.getFechaEntrega().toLocalDate())) {
                cantidad++;
                bruto = bruto.add(p.getSubtotal());
                descuento = descuento.add(p.getDescuento());
                neto = neto.add(p.getTotal());
            }
        }
        return new ResumenCaja(fecha, cantidad, bruto, descuento, neto);
    }
}
