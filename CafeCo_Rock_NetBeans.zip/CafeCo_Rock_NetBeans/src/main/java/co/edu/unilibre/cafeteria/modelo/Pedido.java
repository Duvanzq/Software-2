package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pedido con precios, descuento y fecha de entrega conservados como históricos. */
public final class Pedido {
    private final int id;
    private final LocalDateTime fecha;
    private final List<DetallePedido> detalles;
    private final BigDecimal subtotal;
    private final BigDecimal descuento;
    private final String nombrePromocion;
    private final int idPromocion;
    private EstadoPedido estado;
    private LocalDateTime fechaEntrega;

    public Pedido(int id, LocalDateTime fecha, List<DetallePedido> detalles) {
        this(id, fecha, detalles, ResultadoDescuento.ninguno());
    }

    public Pedido(int id, LocalDateTime fecha, List<DetallePedido> detalles,
                  ResultadoDescuento resultado) {
        if (id <= 0) throw new IllegalArgumentException("El ID del pedido debe ser positivo.");
        if (fecha == null) throw new IllegalArgumentException("La fecha del pedido es obligatoria.");
        if (detalles == null || detalles.isEmpty() || detalles.contains(null))
            throw new IllegalArgumentException("El pedido necesita al menos un producto válido.");
        if (resultado == null) throw new IllegalArgumentException("Falta información del descuento.");
        BigDecimal sum = BigDecimal.ZERO;
        for (DetallePedido detalle : detalles) sum = sum.add(detalle.getSubtotal());
        if (resultado.getMonto().compareTo(sum) > 0)
            throw new IllegalArgumentException("El descuento no puede superar el subtotal.");
        this.id = id;
        this.fecha = fecha;
        this.detalles = Collections.unmodifiableList(new ArrayList<DetallePedido>(detalles));
        this.subtotal = sum;
        this.descuento = resultado.getMonto();
        this.nombrePromocion = resultado.getNombrePromocion();
        this.idPromocion = resultado.getIdPromocion();
        this.estado = EstadoPedido.PENDIENTE;
    }

    public int getId() { return id; }
    public LocalDateTime getFecha() { return fecha; }
    public LocalDateTime getFechaEntrega() { return fechaEntrega; }
    public List<DetallePedido> getDetalles() { return detalles; }
    public EstadoPedido getEstado() { return estado; }
    public BigDecimal getSubtotal() { return subtotal; }
    public BigDecimal getDescuento() { return descuento; }
    public String getNombrePromocion() { return nombrePromocion; }
    public int getIdPromocion() { return idPromocion; }
    public BigDecimal getTotal() { return subtotal.subtract(descuento); }

    public void avanzarEstado() { avanzarEstado(LocalDateTime.now()); }

    public void avanzarEstado(LocalDateTime instante) {
        if (instante == null || instante.isBefore(fecha))
            throw new IllegalArgumentException("La fecha del cambio no puede ser anterior al pedido.");
        EstadoPedido siguiente = estado.siguiente();
        estado = siguiente;
        if (estado == EstadoPedido.ENTREGADO) fechaEntrega = instante;
    }
}
