package co.edu.unilibre.cafeteria.modelo;

/** Categorías iniciales del menú. */
public enum CategoriaProducto {
    BEBIDA("Bebida"),
    ALIMENTO("Alimento"),
    OTRO("Otro");

    private final String nombreVisible;

    CategoriaProducto(String nombreVisible) {
        this.nombreVisible = nombreVisible;
    }

    @Override
    public String toString() {
        return nombreVisible;
    }
}
