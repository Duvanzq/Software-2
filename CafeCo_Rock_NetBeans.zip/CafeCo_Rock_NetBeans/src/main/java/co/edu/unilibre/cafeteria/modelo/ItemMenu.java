package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;

/** Elemento que puede comprarse, con o sin complementos. */
public interface ItemMenu {
    BigDecimal getPrecio();
    String getDescripcion();
}
