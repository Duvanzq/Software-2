package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;

/** Decorator: suma un ingrediente al item sin modificar el producto original. */
public final class Complemento implements ItemMenu {
    private final ItemMenu base;
    private final String nombre;
    private final BigDecimal precioAdicional;

    public Complemento(ItemMenu base, String nombre, BigDecimal precioAdicional) {
        if (base == null) {
            throw new IllegalArgumentException("Debes indicar el producto a personalizar.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del complemento no puede estar vacío.");
        }
        if (precioAdicional == null || precioAdicional.signum() < 0) {
            throw new IllegalArgumentException("El precio adicional no puede ser negativo.");
        }
        this.base = base;
        this.nombre = nombre.trim();
        this.precioAdicional = precioAdicional;
    }

    @Override
    public BigDecimal getPrecio() {
        return base.getPrecio().add(precioAdicional);
    }

    @Override
    public String getDescripcion() {
        return base.getDescripcion() + " + " + nombre;
    }
}
