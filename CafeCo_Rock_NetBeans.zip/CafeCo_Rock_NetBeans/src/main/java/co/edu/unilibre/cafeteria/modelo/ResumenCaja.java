package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Resumen de la jornada: solo pedidos ENTREGADOS en esa fecha. */
public final class ResumenCaja {
    private final LocalDate fecha;
    private final int pedidosEntregados;
    private final BigDecimal subtotalBruto;
    private final BigDecimal descuentos;
    private final BigDecimal ventasNetas;

    public ResumenCaja(LocalDate fecha, int pedidosEntregados, BigDecimal subtotalBruto,
                      BigDecimal descuentos, BigDecimal ventasNetas) {
        this.fecha = fecha;
        this.pedidosEntregados = pedidosEntregados;
        this.subtotalBruto = subtotalBruto;
        this.descuentos = descuentos;
        this.ventasNetas = ventasNetas;
    }

    public LocalDate getFecha() { return fecha; }
    public int getPedidosEntregados() { return pedidosEntregados; }
    public BigDecimal getSubtotalBruto() { return subtotalBruto; }
    public BigDecimal getDescuentos() { return descuentos; }
    public BigDecimal getVentasNetas() { return ventasNetas; }
}
