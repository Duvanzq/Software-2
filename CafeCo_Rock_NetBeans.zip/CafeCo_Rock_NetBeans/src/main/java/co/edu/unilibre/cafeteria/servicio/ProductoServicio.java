package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.Producto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * Lógica de negocio de productos. No depende de la consola ni de Swing:
 * la futura interfaz gráfica reutilizará esta misma clase (RNF07).
 * Almacenamiento temporal en memoria, sin base de datos todavía.
 */
public class ProductoServicio {
    private final Map<Integer, Producto> productos = new LinkedHashMap<Integer, Producto>();
    private int siguienteId = 1;

    public Producto registrar(String nombre, BigDecimal precio,
                             CategoriaProducto categoria, String descripcion) {
        Producto nuevo = new Producto(siguienteId, nombre, precio, categoria, descripcion);
        productos.put(nuevo.getId(), nuevo);
        siguienteId++;
        return nuevo;
    }

    public List<Producto> listar() {
        return new ArrayList<Producto>(productos.values());
    }

    public Producto buscarPorId(int id) {
        Producto producto = productos.get(id);
        if (producto == null) {
            throw new NoSuchElementException("No existe un producto con ID " + id + ".");
        }
        return producto;
    }

    public List<Producto> listarPorCategoria(CategoriaProducto categoria) {
        if (categoria == null) {
            throw new IllegalArgumentException("Debes seleccionar una categoría.");
        }
        List<Producto> resultado = new ArrayList<Producto>();
        for (Producto producto : productos.values()) {
            if (producto.getCategoria() == categoria) {
                resultado.add(producto);
            }
        }
        return resultado;
    }

    public Producto editar(int id, String nombre, BigDecimal precio,
                          CategoriaProducto categoria, String descripcion) {
        buscarPorId(id); // Verifica que exista antes de actualizar.
        Producto actualizado = new Producto(id, nombre, precio, categoria, descripcion);
        productos.put(id, actualizado);
        return actualizado;
    }

    public void eliminar(int id) {
        buscarPorId(id); // Lanza una excepción clara si no existe.
        productos.remove(id);
    }
}
