package co.edu.unilibre.cafeteria.promocion;

import java.math.BigDecimal;

/** Descuento en COP, limitado al subtotal de la compra. */
public final class DescuentoFijo implements PoliticaDescuento {
    private final BigDecimal monto;

    public DescuentoFijo(BigDecimal monto) {
        if (monto == null || monto.signum() <= 0) {
            throw new IllegalArgumentException("El descuento fijo debe ser mayor que cero.");
        }
        this.monto = monto;
    }

    @Override
    public BigDecimal calcularDescuento(BigDecimal subtotal) {
        DescuentoPorcentaje.validarSubtotal(subtotal);
        return monto.min(subtotal);
    }

    @Override
    public String describir() {
        return monto.stripTrailingZeros().toPlainString() + " COP de descuento";
    }
}
