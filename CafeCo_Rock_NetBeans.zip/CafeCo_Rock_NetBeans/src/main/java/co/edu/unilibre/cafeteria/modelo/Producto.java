package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;

/** Producto del menú con datos validados. El precio se maneja con BigDecimal. */
public final class Producto implements ItemMenu {
    private final int id;
    private final String nombre;
    private final BigDecimal precio;
    private final CategoriaProducto categoria;
    private final String descripcion;

    public Producto(int id, String nombre, BigDecimal precio,
                    CategoriaProducto categoria, String descripcion) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser positivo.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (precio == null || precio.signum() <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que cero.");
        }
        if (categoria == null) {
            throw new IllegalArgumentException("Debes seleccionar una categoría.");
        }
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción no puede estar vacía.");
        }

        this.id = id;
        this.nombre = nombre.trim();
        this.precio = precio;
        this.categoria = categoria;
        this.descripcion = descripcion.trim();
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public BigDecimal getPrecio() { return precio; }
    public CategoriaProducto getCategoria() { return categoria; }
    public String getDescripcion() { return descripcion; }
}
