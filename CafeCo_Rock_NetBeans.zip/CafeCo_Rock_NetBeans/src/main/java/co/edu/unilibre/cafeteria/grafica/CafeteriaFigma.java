package co.edu.unilibre.cafeteria.grafica;

import co.edu.unilibre.cafeteria.modelo.*;
import co.edu.unilibre.cafeteria.promocion.*;
import co.edu.unilibre.cafeteria.servicio.ContextoCafeteria;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Implementación Swing inspirada en el archivo Figma Café & Co.
 * https://www.figma.com/design/eyfhUH8rAQDfTdz7i94Lil
 * Todos los datos y reglas se obtienen de ContextoCafeteria.
 * Las pantallas se implementan con JPanel; no dependen de HTML ni de una base de datos.
 */
public final class CafeteriaFigma extends JFrame {
    private static final Color ESPRESSO = rgb("#191A1C");
    private static final Color DARK = rgb("#222326");
    private static final Color CREAM = rgb("#EEEADF");
    private static final Color WHITE = rgb("#FFFCF5");
    private static final Color CARAMEL = rgb("#B43A2C");
    private static final Color MOCHA = rgb("#777167");
    private static final Color SAGE = rgb("#D1AA4A");
    private static final Color GREEN = rgb("#326455");
    private static final Color TERRACOTTA = rgb("#A3332A");
    private static final Color MUTED = rgb("#777167");
    private static final Color LINE = rgb("#D9D1C4");
    private static final Color HEAD = rgb("#E8E1D6");
    private static final Font NORMAL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font SMALL = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font HEADING = new Font("Arial Narrow", Font.BOLD | Font.ITALIC, 32);
    private static final Font BOLD = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font DISPLAY = new Font("Arial Narrow", Font.BOLD | Font.ITALIC, 34);
    private static final Color GOLD = rgb("#D1AA4A");
    private final ContextoCafeteria contexto;
    private final NumberFormat money = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));
    private final DateTimeFormatter hourFormat = DateTimeFormatter.ofPattern("HH:mm");
    private final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d 'de' MMMM 'de' yyyy", new Locale("es", "CO"));
    private final JPanel main = new JPanel(new BorderLayout());
    private final JPanel nav = new JPanel();
    private final JLabel currentTitle = new JLabel();
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();
    private final List<LineaCarrito> cart = new ArrayList<>();
    private String screen = "Inicio";
    private LocalDate cajaFecha;
    private int pedidoSeleccionado = -1;

    public CafeteriaFigma() { this(new ContextoCafeteria()); }

    public CafeteriaFigma(ContextoCafeteria contexto) {
        super("CAFÉ & CO. — COFFEE / VINYL / ROCK N’ ROLL");
        this.contexto = Objects.requireNonNull(contexto);
        this.cajaFecha = LocalDate.now(contexto.getReloj());
        money.setMaximumFractionDigits(0);
        money.setMinimumFractionDigits(0);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1130, 740));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        try { java.net.URL icon = getClass().getResource("/cafeco_icon.png"); if(icon!=null)setIconImage(new ImageIcon(icon).getImage()); } catch(Exception ignore) {}
        UIManager.put("Separator.foreground",LINE);
        UIManager.put("Separator.background",LINE);
        UIManager.put("ProgressBar.border",BorderFactory.createEmptyBorder());
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(CREAM);
        getContentPane().add(sidebar(), BorderLayout.WEST);
        main.setBackground(CREAM);
        getContentPane().add(main, BorderLayout.CENTER);
        showScreen("Inicio");
    }

    private JPanel sidebar() {
        JPanel side = new JPanel(new BorderLayout());
        side.setPreferredSize(new Dimension(232, 0));
        side.setBackground(ESPRESSO);
        JPanel top = new JPanel(new BorderLayout(8,0));
        top.setOpaque(false);
        top.setBorder(new EmptyBorder(23,20,24,12));
        JLabel cup = label("☕", 23, ESPRESSO,true);
        cup.setOpaque(true);cup.setBackground(GOLD);cup.setHorizontalAlignment(SwingConstants.CENTER);
        cup.setPreferredSize(new Dimension(44,44));
        top.add(cup,BorderLayout.WEST);
        JPanel brand = new JPanel();brand.setOpaque(false);brand.setLayout(new BoxLayout(brand,BoxLayout.Y_AXIS));
        brand.add(label("CAFÉ & CO.",22,WHITE,true));
        brand.add(label("Gestión de cafetería",10,rgb("#BFB9AF"),false));
        top.add(brand,BorderLayout.CENTER);
        JPanel logoBlock = new JPanel(new BorderLayout());logoBlock.setOpaque(false);
        logoBlock.add(top,BorderLayout.CENTER);
        JPanel stripes = new JPanel(new GridLayout(1,3,3,0));stripes.setOpaque(false);
        stripes.setBorder(new EmptyBorder(0,19,0,19));
        for(Color c: new Color[]{CARAMEL,GOLD,WHITE}){
            JPanel bar=new JPanel();bar.setBackground(c);bar.setPreferredSize(new Dimension(45,3));stripes.add(bar);
        }
        logoBlock.add(stripes,BorderLayout.SOUTH);
        side.add(logoBlock,BorderLayout.NORTH);

        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav,BoxLayout.Y_AXIS));
        nav.setBorder(new EmptyBorder(26,12,0,12));
        addNav("Inicio", "⌂");
        addNav("Productos", "◇");
        addNav("Nuevo pedido", "+");
        addNav("Pedidos", "≡");
        addNav("Promociones", "♢");
        addNav("Cierre de caja", "▣");
        side.add(nav,BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout(0,12));south.setOpaque(false);
        south.setBorder(new EmptyBorder(0,18,18,18));
        JPanel poster = new RockPoster();poster.setPreferredSize(new Dimension(191,250));
        south.add(poster,BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout(0,8));bottom.setOpaque(false);
        bottom.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1,0,0,0,rgb("#696967")),new EmptyBorder(12,0,0,0)));
        bottom.add(label("Jornada local",12,WHITE,true),BorderLayout.NORTH);
        bottom.add(label(LocalDate.now(contexto.getReloj()).format(dateFormat),10,
                rgb("#BEBAB3"),false),BorderLayout.SOUTH);
        south.add(bottom,BorderLayout.SOUTH);
        side.add(south,BorderLayout.SOUTH);
        return side;
    }

    private void addNav(String title, String symbol) {
        JButton button = new JButton("  " + symbol + "     " + title);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(208, 43));
        button.setPreferredSize(new Dimension(208, 43));
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(0, 10, 0, 0));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setForeground(WHITE);
        button.setBackground(ESPRESSO);
        button.setOpaque(true);
        button.addActionListener(e -> showScreen(title));
        nav.add(button);
        nav.add(Box.createVerticalStrut(9));
        navButtons.put(title, button);
    }

    private void showScreen(String name) {
        this.screen = name;
        for (Map.Entry<String, JButton> e : navButtons.entrySet()) {
            boolean active = name.equals(e.getKey());
            e.getValue().setBackground(active ? GOLD : ESPRESSO);
            e.getValue().setForeground(active ? ESPRESSO : WHITE);
            e.getValue().setFont(new Font("Segoe UI", active ? Font.BOLD : Font.PLAIN, 14));
        }
        main.removeAll();
        main.add(header(name), BorderLayout.NORTH);
        JPanel contents;
        switch (name) {
            case "Productos": contents = productsPage(); break;
            case "Nuevo pedido": contents = newOrderPage(); break;
            case "Pedidos": contents = ordersPage(); break;
            case "Promociones": contents = promotionsPage(); break;
            case "Cierre de caja": contents = cashPage(); break;
            default: contents = homePage();
        }
        JScrollPane scroller = new JScrollPane(contents,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller.setBorder(null);
        scroller.getViewport().setBackground(CREAM);
        scroller.getVerticalScrollBar().setUnitIncrement(18);
        main.add(scroller, BorderLayout.CENTER);
        main.revalidate();
        main.repaint();
    }

    private JPanel header(String name) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(WHITE);
        p.setPreferredSize(new Dimension(0, 59));
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,2,0,CARAMEL),new EmptyBorder(0,32,0,20)));
        currentTitle.setText(name);
        currentTitle.setFont(BOLD);
        currentTitle.setPreferredSize(new Dimension(180, 28));
        currentTitle.setForeground(ESPRESSO);
        p.add(currentTitle, BorderLayout.WEST);
        JLabel brandline=label("C O F F E E  /  V I N Y L  /  R O C K  ' N '  R O L L",10,MOCHA,true);
        brandline.setHorizontalAlignment(SwingConstants.CENTER);
        p.add(brandline,BorderLayout.CENTER);
        p.add(label("▦  " + LocalDate.now(contexto.getReloj()).format(dateFormat), 12, MUTED, false), BorderLayout.EAST);
        return p;
    }

    private JPanel page(String title, String intro, String button, Runnable action) {
        JPanel base = new ScrollPage();
        base.setLayout(new BoxLayout(base, BoxLayout.Y_AXIS));
        base.setBackground(CREAM);
        base.setBorder(new EmptyBorder(28, 32, 35, 32));
        JPanel top = new JPanel(new BorderLayout(10, 0));
        top.setOpaque(false);
        top.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        JLabel heading=label(title.toUpperCase(new Locale("es","CO")),32,ESPRESSO,true);
        heading.setFont(DISPLAY);
        titles.add(heading);
        titles.add(Box.createVerticalStrut(5));
        titles.add(label(intro, 13, MUTED, false));
        top.add(titles, BorderLayout.WEST);
        if (button != null) {
            JPanel actionBox=new JPanel(new FlowLayout(FlowLayout.RIGHT,0,0)); actionBox.setOpaque(false);
            JButton primary=button(button,CARAMEL,WHITE,action);
            primary.setPreferredSize(new Dimension(Math.max(135,button.length()*9+30),42));
            actionBox.add(primary);top.add(actionBox,BorderLayout.EAST);
        }
        base.add(top);
        base.add(Box.createVerticalStrut(20));
        return base;
    }

    private JPanel homePage() {
        JPanel base = page("Bienvenido a Café & Co.", "Consulta la actividad de la jornada.", "+ Nuevo pedido", () -> showScreen("Nuevo pedido"));
        List<Pedido> orders = contexto.getPedidos().listar();
        long waiting = orders.stream().filter(o -> o.getEstado() == EstadoPedido.PENDIENTE).count();
        ResumenCaja today = contexto.getCaja().resumir(LocalDate.now(contexto.getReloj()));
        long delivered = today.getPedidosEntregados();
        JPanel metrics = row(16);
        metrics.add(stat("Ventas de la jornada", price(today.getVentasNetas()), "Solo pedidos entregados"));
        metrics.add(stat("Pedidos registrados", "" + orders.size(), "En todos los estados"));
        metrics.add(stat("Pedidos pendientes", "" + waiting, "Por preparar"));
        metrics.add(stat("Pedidos entregados", "" + delivered, "Incluidos en el cierre"));
        base.add(metrics);
        base.add(Box.createVerticalStrut(24));
        base.add(label("ÚLTIMOS PEDIDOS", 22, ESPRESSO, true));
        base.add(Box.createVerticalStrut(13));
        JPanel middle = new JPanel(new BorderLayout(18,0)); middle.setOpaque(false); middle.setAlignmentX(Component.LEFT_ALIGNMENT);
        List<Pedido> recent = new ArrayList<>(orders);
        Collections.reverse(recent);
        if (recent.size() > 6) recent = recent.subList(0, 6);
        Object[][] data = new Object[recent.size()][4];
        int i=0;
        for (Pedido o: recent) {
            data[i++] = new Object[] {orderId(o.getId()), o.getFecha().format(hourFormat), o.getEstado().toString(), price(o.getTotal())};
        }
        JPanel tableCard = card(new BorderLayout());
        tableCard.add(table(data, new String[]{"Pedido", "Hora", "Estado", "Total (COP)"}), BorderLayout.CENTER);
        tableCard.setPreferredSize(new Dimension(730, 290));
        middle.add(tableCard, BorderLayout.CENTER);
        JPanel status = card();
        status.setPreferredSize(new Dimension(260, 290));
        status.setLayout(new BoxLayout(status, BoxLayout.Y_AXIS));
        status.add(label("Estados de pedidos", 17, ESPRESSO, true));
        status.add(Box.createVerticalStrut(14));
        for (EstadoPedido st : EstadoPedido.values()) {
            long count = orders.stream().filter(o -> o.getEstado() == st).count();
            status.add(label(st.toString() + "   ·   " + count, 13, DARK, true));
            status.add(Box.createVerticalStrut(7));
            JProgressBar bar = new JProgressBar(0, Math.max(1, orders.size()));
            bar.setValue((int) count); bar.setStringPainted(false);
            bar.setForeground(st==EstadoPedido.ENTREGADO ? ESPRESSO : st==EstadoPedido.LISTO ? SAGE : CARAMEL);
            bar.setBackground(HEAD); bar.setBorder(BorderFactory.createEmptyBorder()); bar.setPreferredSize(new Dimension(200, 7));
            bar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 7));
            status.add(bar); status.add(Box.createVerticalStrut(17));
        }
        middle.add(status, BorderLayout.EAST);
        base.add(middle);
        base.add(Box.createVerticalStrut(15));
        base.add(label("ACCESOS RÁPIDOS", 20, ESPRESSO, true));
        base.add(Box.createVerticalStrut(9));
        JPanel quick = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); quick.setOpaque(false);
        quick.add(button("Registrar producto", WHITE, DARK, () -> editProduct(null)));
        quick.add(button("Nuevo pedido", WHITE, DARK, () -> showScreen("Nuevo pedido")));
        quick.add(button("Ver pedidos", WHITE, DARK, () -> showScreen("Pedidos")));
        JPanel footerRow=new JPanel(new BorderLayout(24,0));footerRow.setOpaque(false);
        footerRow.setPreferredSize(new Dimension(1020,162));footerRow.setMaximumSize(new Dimension(Integer.MAX_VALUE,162));
        JPanel quickHolder=new JPanel(new BorderLayout());quickHolder.setOpaque(false);
        quickHolder.add(quick,BorderLayout.NORTH);
        quickHolder.setPreferredSize(new Dimension(350,162));
        footerRow.add(quickHolder,BorderLayout.WEST);
        footerRow.add(new BrandBanner("BUEN CAFÉ.   BUEN ROCK."),BorderLayout.CENTER);
        base.add(footerRow);
        return base;
    }

    private JPanel productsPage() {
        JPanel base = page("Productos", "Administra el catálogo de bebidas y alimentos.", "+ Agregar producto", () -> editProduct(null));
        JTextField search = input(23); search.putClientProperty("JTextField.placeholderText", "Buscar por nombre o ID");
        JComboBox<String> category = combo("Todas las categorías", "Bebida", "Alimento", "Otro");
        JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));tools.setOpaque(false);
        tools.add(search); tools.add(category);
        base.add(tools);base.add(Box.createVerticalStrut(14));
        JLabel count = label("", 12, MUTED, false);base.add(count);base.add(Box.createVerticalStrut(10));
        Object[] headings = {"ID", "Nombre", "Categoría", "Precio (COP)", "Descripción"};
        DefaultTableModel model = model(headings);
        JTable grid = styledTable(model);
        JScrollPane scroll = scroll(grid);
        scroll.setPreferredSize(new Dimension(800, 320));
        base.add(scroll);
        JLabel chosen = label("Selecciona un producto para editarlo o eliminarlo.",12,MUTED,false);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,0)); actions.setOpaque(false);
        JButton edit = button("Editar", WHITE, DARK, () -> {
            int selected = selectedId(grid, model, 0, "Selecciona un producto para editar.");
            editProduct(contexto.getProductos().buscarPorId(selected));
        });
        JButton delete = button("Eliminar", rgb("#F4E2DB"), TERRACOTTA, () -> {
            int selected = selectedId(grid, model, 0, "Selecciona un producto para eliminar.");
            Producto product = contexto.getProductos().buscarPorId(selected);
            if (confirm("¿Eliminar " + product.getNombre() + " del catálogo?")) {
                contexto.getProductos().eliminar(selected);
                showScreen("Productos");
            }
        });
        actions.add(edit);actions.add(delete);
        base.add(Box.createVerticalStrut(13));base.add(actions);base.add(chosen);
        grid.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && grid.getSelectedRow() >= 0)
                chosen.setText("Producto seleccionado · " + grid.getValueAt(grid.getSelectedRow(), 0) + " " + grid.getValueAt(grid.getSelectedRow(), 1));
        });
        Runnable update = () -> {
            model.setRowCount(0); int total=0;
            String q = search.getText().trim().toLowerCase(new Locale("es", "CO"));
            for (Producto p: contexto.getProductos().listar()) {
                if (!q.isEmpty() && !p.getNombre().toLowerCase(new Locale("es", "CO")).contains(q) && !String.valueOf(p.getId()).contains(q)) continue;
                if (category.getSelectedIndex()>0 && !p.getCategoria().toString().equals(category.getSelectedItem())) continue;
                model.addRow(new Object[]{String.valueOf(p.getId()), p.getNombre(), p.getCategoria().toString(), price(p.getPrecio()), p.getDescripcion()});total++;
            }
            count.setText(total + " productos");
        };
        search.getDocument().addDocumentListener(listener(update));category.addActionListener(e -> update.run());update.run();
        return base;
    }

    private JPanel newOrderPage() {
        JPanel base = page("Nuevo pedido", "Agrega productos y revisa el total antes de registrar.", "Ver pedidos", () -> showScreen("Pedidos"));
        JPanel split = new JPanel(new BorderLayout(18,0)); split.setOpaque(false); split.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel catalog = card(new BorderLayout(0,14));
        catalog.setPreferredSize(new Dimension(600, 570));
        catalog.add(label("CATÁLOGO",22,ESPRESSO,true),BorderLayout.NORTH);
        JPanel catalogBody = new JPanel(new BorderLayout(0,12)); catalogBody.setOpaque(false);
        JTextField filter = input(20);
        filter.putClientProperty("JTextField.placeholderText", "Buscar producto");
        JComboBox<String> cat = combo("Todas", "Bebida", "Alimento", "Otro");
        JPanel filterRow = new JPanel(new BorderLayout(9,0));filterRow.setOpaque(false);
        filterRow.add(filter,BorderLayout.CENTER); filterRow.add(cat,BorderLayout.EAST);
        catalogBody.add(filterRow,BorderLayout.NORTH);
        JPanel items = new JPanel();items.setBackground(WHITE);items.setLayout(new BoxLayout(items, BoxLayout.Y_AXIS));
        JScrollPane itemScroll = new JScrollPane(items);itemScroll.setBorder(null);itemScroll.getVerticalScrollBar().setUnitIncrement(18);
        catalogBody.add(itemScroll,BorderLayout.CENTER);
        catalog.add(catalogBody,BorderLayout.CENTER);
        Runnable fillItems = () -> {
            items.removeAll(); int found=0;
            for (Producto p: contexto.getProductos().listar()) {
                String q=filter.getText().trim().toLowerCase();
                if (!p.getNombre().toLowerCase().contains(q)) continue;
                if (cat.getSelectedIndex()>0 && !p.getCategoria().toString().equals(cat.getSelectedItem()))continue;
                JPanel line = new JPanel(new BorderLayout(12,0));line.setBackground(WHITE);
                line.setBorder(new EmptyBorder(10,3,11,3));
                JPanel info = new JPanel();info.setOpaque(false);info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS));
                info.add(label((p.getCategoria()==CategoriaProducto.BEBIDA?"☕  ":"♧  ")+p.getNombre(),14,DARK,true));
                info.add(Box.createVerticalStrut(4));info.add(label(p.getCategoria()+"  ·  "+price(p.getPrecio()),12,MUTED,false));
                line.add(info,BorderLayout.CENTER);
                line.add(button("+ Agregar",WHITE,ESPRESSO,()->addToCart(p)),BorderLayout.EAST);
                line.setMaximumSize(new Dimension(Integer.MAX_VALUE,68));
                items.add(line);JSeparator sep = separator();sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,1));items.add(sep);found++;
            }
            if(found==0)items.add(label("No hay productos. Registra productos desde el menú lateral.",13,MUTED,false));
            items.revalidate();items.repaint();
        };
        filter.getDocument().addDocumentListener(listener(fillItems));cat.addActionListener(e->fillItems.run());fillItems.run();
        split.add(catalog,BorderLayout.CENTER);
        JPanel orderCard=card(new BorderLayout(0,12));orderCard.setPreferredSize(new Dimension(385,570));
        JPanel head=new JPanel(new BorderLayout());head.setOpaque(false);
        head.add(label("PEDIDO ACTUAL",20,ESPRESSO,true),BorderLayout.WEST);
        int units=cart.stream().mapToInt(line->line.quantity).sum();
        head.add(label(units+" unidades",12,MUTED,false),BorderLayout.EAST);
        orderCard.add(head,BorderLayout.NORTH);
        JPanel orderLines=new JPanel();orderLines.setBackground(WHITE);orderLines.setLayout(new BoxLayout(orderLines,BoxLayout.Y_AXIS));
        for(LineaCarrito item: new ArrayList<>(cart)){
            JPanel cell=new JPanel(new BorderLayout(10,4));cell.setBorder(new EmptyBorder(12,0,12,0));cell.setBackground(WHITE);
            JPanel names=new JPanel();names.setOpaque(false);names.setLayout(new BoxLayout(names,BoxLayout.Y_AXIS));
            names.add(label(item.product.getNombre(),13,DARK,true));
            names.add(label(item.decorated.getDescripcion(),11,MUTED,false));
            JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT,4,4));controls.setOpaque(false);
            controls.add(button("−",WHITE,ESPRESSO,()->{if(item.quantity>1)item.quantity--;else cart.remove(item);showScreen("Nuevo pedido");}));
            controls.add(label("  "+item.quantity+"  ",13,ESPRESSO,false));
            controls.add(button("+",WHITE,ESPRESSO,()->{item.quantity++;showScreen("Nuevo pedido");}));
            controls.add(button("Quitar",WHITE,TERRACOTTA,()->{cart.remove(item);showScreen("Nuevo pedido");}));
            names.add(controls);cell.add(names,BorderLayout.CENTER);
            cell.add(label(price(item.decorated.getPrecio().multiply(BigDecimal.valueOf(item.quantity))),13,DARK,true),BorderLayout.EAST);
            cell.setMaximumSize(new Dimension(Integer.MAX_VALUE,125));orderLines.add(cell);orderLines.add(separator());
        }
        if(cart.isEmpty())orderLines.add(label("Agrega productos del catálogo para empezar.",13,MUTED,false));
        JScrollPane cartScroll = new JScrollPane(orderLines);cartScroll.setBorder(null);
        orderCard.add(cartScroll,BorderLayout.CENTER);
        JPanel totalPanel=new LeftStack();
        BigDecimal subtotal=BigDecimal.ZERO;
        for(LineaCarrito item:cart) subtotal=subtotal.add(item.decorated.getPrecio().multiply(BigDecimal.valueOf(item.quantity)));
        ResultadoDescuento discount=contexto.getPromociones().mejorAplicable(subtotal,LocalDateTime.now(contexto.getReloj()));
        totalPanel.add(amountLine("Subtotal",price(subtotal),false));
        totalPanel.add(Box.createVerticalStrut(6));
        totalPanel.add(amountLine("Descuento", "− "+price(discount.getMonto()),false));
        if(discount.getMonto().signum()>0)totalPanel.add(label(discount.getNombrePromocion(),11,GREEN,false));
        totalPanel.add(Box.createVerticalStrut(11));
        JPanel grand=rounded(new BorderLayout(),HEAD);
        grand.setBorder(new EmptyBorder(10,12,10,12));
        grand.add(label("Total (COP)",13,ESPRESSO,true),BorderLayout.WEST);
        grand.add(label(price(subtotal.subtract(discount.getMonto())),19,ESPRESSO,true),BorderLayout.EAST);
        totalPanel.add(grand);totalPanel.add(Box.createVerticalStrut(12));
        JButton save=button("Registrar pedido",CARAMEL,WHITE,()->saveOrder());
        save.setAlignmentX(Component.LEFT_ALIGNMENT);save.setMaximumSize(new Dimension(Integer.MAX_VALUE,42));
        save.setEnabled(!cart.isEmpty());totalPanel.add(save);
        orderCard.add(totalPanel,BorderLayout.SOUTH);split.add(orderCard,BorderLayout.EAST);base.add(split);
        return base;
    }

    private JPanel ordersPage() {
        JPanel base = page("Seguimiento de pedidos", "Consulta los detalles y actualiza el estado de cada pedido.", "+ Nuevo pedido",()->showScreen("Nuevo pedido"));
        JPanel split = new JPanel(new BorderLayout(18,0)); split.setOpaque(false); split.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel left=new JPanel();left.setOpaque(false);left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS));
        JTextField query=input(19);JComboBox<String> filter=combo("Todos los estados","Pendiente","En preparación","Listo","Entregado");
        JPanel tools=new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));tools.setOpaque(false);tools.add(query);tools.add(filter);
        left.add(tools);left.add(Box.createVerticalStrut(16));
        DefaultTableModel model=model(new Object[]{"Pedido", "Hora", "Estado", "Total (COP)"});
        JTable table=styledTable(model);JScrollPane sp=scroll(table);
        sp.setPreferredSize(new Dimension(650,315));left.add(sp);
        left.add(Box.createVerticalStrut(15));left.add(label("Secuencia de estados: Pendiente  →  En preparación  →  Listo  →  Entregado",12,MUTED,false));
        left.setPreferredSize(new Dimension(650,420));split.add(left,BorderLayout.CENTER);
        JPanel detail=card(new BorderLayout(0,12)); detail.setPreferredSize(new Dimension(320,410));split.add(detail,BorderLayout.EAST);
        Runnable renderDetail=()->{
            detail.removeAll();
            if(pedidoSeleccionado < 0){detail.add(label("Selecciona un pedido para consultar su detalle.",13,MUTED,false),BorderLayout.NORTH);detail.revalidate();detail.repaint();return;}
            try {
                Pedido p=contexto.getPedidos().buscarPorId(pedidoSeleccionado);
                JPanel text=new JPanel();text.setOpaque(false);text.setLayout(new BoxLayout(text,BoxLayout.Y_AXIS));
                text.add(label("Detalle del pedido",18,ESPRESSO,true));text.add(Box.createVerticalStrut(12));
                text.add(label(orderId(p.getId())+" · "+p.getFecha().format(hourFormat),12,MUTED,false));text.add(Box.createVerticalStrut(7));
                text.add(label(p.getEstado().toString(),12,stateColor(p.getEstado()),true));text.add(Box.createVerticalStrut(17));
                text.add(separator());text.add(Box.createVerticalStrut(12));
                text.add(label("Productos",13,ESPRESSO,true));text.add(Box.createVerticalStrut(8));
                for(DetallePedido d:p.getDetalles()){
                    text.add(label(d.getCantidad()+" × "+d.getNombreProducto(),12,DARK,false));
                    text.add(label(d.getDescripcion(),11,MUTED,false));text.add(Box.createVerticalStrut(9));
                }
                detail.add(text,BorderLayout.NORTH);
                JPanel foot=new JPanel();foot.setOpaque(false);foot.setLayout(new BoxLayout(foot,BoxLayout.Y_AXIS));
                foot.add(amountLine("Descuento", "− "+price(p.getDescuento()),false));foot.add(Box.createVerticalStrut(9));
                foot.add(amountLine("Total (COP)",price(p.getTotal()),true));foot.add(Box.createVerticalStrut(13));
                if(p.getEstado()!=EstadoPedido.ENTREGADO){
                    JButton next=button("Marcar: "+p.getEstado().siguiente().toString(),CARAMEL,WHITE,()->runSafe(()->{
                        contexto.getPedidos().avanzarEstado(p.getId());showScreen("Pedidos");}));
                    next.setMaximumSize(new Dimension(Integer.MAX_VALUE,45));foot.add(next);
                }else foot.add(label("✓ Pedido entregado",13,GREEN,true));
                detail.add(foot,BorderLayout.SOUTH);
            }catch(RuntimeException ex){pedidoSeleccionado=-1;detail.add(label("Pedido no encontrado.",13,MUTED,false),BorderLayout.NORTH);}
            detail.revalidate();detail.repaint();
        };
        Runnable fill=()->{
            model.setRowCount(0);
            List<Pedido> orders=contexto.getPedidos().listar();Collections.reverse(orders);
            for(Pedido p:orders){
                if(!String.valueOf(p.getId()).contains(query.getText().trim().replace("#","")))continue;
                if(filter.getSelectedIndex()>0 && !p.getEstado().toString().equals(filter.getSelectedItem()))continue;
                model.addRow(new Object[]{orderId(p.getId()),p.getFecha().format(hourFormat),p.getEstado().toString(),price(p.getTotal())});
            }
            if(model.getRowCount()>0){
                int wanted=0;
                for(int i=0;i<model.getRowCount();i++)if(parseOrderId(model.getValueAt(i,0).toString())==pedidoSeleccionado){wanted=i;break;}
                table.setRowSelectionInterval(wanted,wanted);
                pedidoSeleccionado=parseOrderId(model.getValueAt(wanted,0).toString());
            }else pedidoSeleccionado=-1;
            renderDetail.run();
        };
        table.getSelectionModel().addListSelectionListener(e->{if(!e.getValueIsAdjusting()&&table.getSelectedRow()>=0){pedidoSeleccionado=parseOrderId(table.getValueAt(table.getSelectedRow(),0).toString());renderDetail.run();}});
        query.getDocument().addDocumentListener(listener(fill));filter.addActionListener(e->fill.run());fill.run();base.add(split);
        return base;
    }

    private JPanel promotionsPage() {
        JPanel base=page("Promociones", "Programa descuentos por día y horario.", "+ Crear promoción",()->editPromotion());
        JPanel banner=rounded(new BorderLayout(),rgb("#E3EBE0"));banner.setBorder(new EmptyBorder(15,17,15,17));
        banner.add(label("◇   Descuentos automáticos: se aplican al registrar pedidos dentro de los días y horarios vigentes.",13,GREEN,true));
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE,54));base.add(banner);base.add(Box.createVerticalStrut(18));
        JComboBox<String> choice=combo("Todas las promociones","Activas","Inactivas");
        JPanel filters=new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));filters.setOpaque(false);filters.add(choice);base.add(filters);base.add(Box.createVerticalStrut(15));
        DefaultTableModel model=model(new Object[]{"ID", "Promoción", "Descuento", "Días", "Horario", "Estado"});
        JTable table=styledTable(model);JScrollPane sp=scroll(table);
        sp.setPreferredSize(new Dimension(900,300));base.add(sp);
        JPanel tools=new JPanel(new FlowLayout(FlowLayout.RIGHT,10,0));tools.setOpaque(false);
        tools.add(button("Activar / Desactivar",WHITE,DARK,()->{
            int id=selectedId(table,model,0,"Selecciona una promoción.");Promocion p=contexto.getPromociones().buscarPorId(id);
            contexto.getPromociones().cambiarActiva(id,!p.isActiva());showScreen("Promociones");
        }));
        tools.add(button("Eliminar",rgb("#F4E2DB"),TERRACOTTA,()->{
            int id=selectedId(table,model,0,"Selecciona una promoción.");
            if(confirm("¿Eliminar esta promoción?")){contexto.getPromociones().eliminar(id);showScreen("Promociones");}
        }));
        base.add(Box.createVerticalStrut(13));base.add(tools);
        base.add(label("Los horarios utilizan formato de 24 horas. Se aplica únicamente la promoción de mayor ahorro.",12,MUTED,false));
        base.add(Box.createVerticalStrut(25));
        base.add(new BrandBanner("EL MEJOR PLAN: CAFÉ Y BUEN ROCK."));
        Runnable fill=()->{
            model.setRowCount(0);
            for(Promocion p:contexto.getPromociones().listar()){
                if(choice.getSelectedIndex()==1&&!p.isActiva())continue;
                if(choice.getSelectedIndex()==2&&p.isActiva())continue;
                model.addRow(new Object[]{p.getId(),p.getNombre(),p.getRegla(),days(p.getDias()),p.getInicio()+"–"+p.getFin(),p.isActiva()?"Activa":"Inactiva"});
            }
        };
        choice.addActionListener(e->fill.run());fill.run();
        return base;
    }

    private JPanel cashPage() {
        JPanel base=page("Cierre de caja", "Resumen de ventas de la jornada.",null,null);
        JPanel chooser=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));chooser.setOpaque(false);
        chooser.add(label("Fecha de entrega",13,ESPRESSO,true));
        JTextField date=input(12);date.setText(cajaFecha.toString());chooser.add(date);
        chooser.add(button("Consultar",WHITE,ESPRESSO,()->runSafe(()->{cajaFecha=LocalDate.parse(date.getText().trim());showScreen("Cierre de caja");})));
        chooser.add(button("Hoy",WHITE,ESPRESSO,()->{cajaFecha=LocalDate.now(contexto.getReloj());showScreen("Cierre de caja");}));
        base.add(chooser);base.add(Box.createVerticalStrut(16));
        ResumenCaja resumen=contexto.getCaja().resumir(cajaFecha);
        JPanel stats=row(16);
        stats.add(stat("Pedidos entregados",String.valueOf(resumen.getPedidosEntregados()),"Pedidos incluidos"));
        stats.add(stat("Ventas antes de descuentos",price(resumen.getSubtotalBruto()),"Subtotal acumulado"));
        stats.add(stat("Descuentos aplicados",price(resumen.getDescuentos()),"Solo pedidos entregados"));
        base.add(stats);base.add(Box.createVerticalStrut(27));
        base.add(label("PEDIDOS INCLUIDOS",21,ESPRESSO,true));base.add(Box.createVerticalStrut(13));
        List<Object[]> rows=new ArrayList<>();
        for(Pedido p:contexto.getPedidos().listar()){
            if(p.getEstado()==EstadoPedido.ENTREGADO&&p.getFechaEntrega()!=null&&p.getFechaEntrega().toLocalDate().equals(cajaFecha))
                rows.add(new Object[]{orderId(p.getId()),p.getFechaEntrega().format(hourFormat),price(p.getSubtotal()),price(p.getDescuento()),price(p.getTotal())});
        }
        Collections.reverse(rows);
        JTable t=styledTable(model(new Object[]{"Pedido","Hora","Subtotal","Descuento","Total (COP)"}));
        DefaultTableModel m=(DefaultTableModel)t.getModel();for(Object[] row:rows)m.addRow(row);
        JScrollPane sp=scroll(t);sp.setPreferredSize(new Dimension(950,270));base.add(sp);
        base.add(Box.createVerticalStrut(27));
        JPanel grand=rounded(new BorderLayout(),ESPRESSO);grand.setBorder(new EmptyBorder(19,24,19,24));
        grand.add(label("Total de ingresos contabilizados",17,WHITE,true),BorderLayout.WEST);
        grand.add(label(price(resumen.getVentasNetas())+" COP",25,WHITE,true),BorderLayout.EAST);
        grand.setMaximumSize(new Dimension(Integer.MAX_VALUE,80));base.add(grand);
        return base;
    }

    private void editProduct(Producto old) {
        JTextField name=input(22),amount=input(13),description=input(26);
        JComboBox<CategoriaProducto> category=new JComboBox<>(CategoriaProducto.values());styleCombo(category);
        if(old!=null){name.setText(old.getNombre());amount.setText(old.getPrecio().toPlainString());category.setSelectedItem(old.getCategoria());description.setText(old.getDescripcion());}
        JPanel form=form();form.add(field("Nombre del producto",name));form.add(field("Precio en COP",amount));
        form.add(field("Categoría",category));form.add(field("Descripción",description));
        while(true){
            int result=JOptionPane.showConfirmDialog(this,form,old==null?"Agregar producto":"Editar producto",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
            if(result!=JOptionPane.OK_OPTION)return;
            try{
                BigDecimal price=new BigDecimal(amount.getText().trim().replace(",","."));
                if(old==null)contexto.getProductos().registrar(name.getText(),price,(CategoriaProducto)category.getSelectedItem(),description.getText());
                else contexto.getProductos().editar(old.getId(),name.getText(),price,(CategoriaProducto)category.getSelectedItem(),description.getText());
                showScreen("Productos");return;
            }catch(RuntimeException e){warn(e.getMessage());}
        }
    }

    private void addToCart(Producto p) {
        JCheckBox[] checks={new JCheckBox("Leche adicional  (+ $1.500)"),new JCheckBox("Crema  (+ $1.000)"),new JCheckBox("Queso  (+ $2.000)")};
        for(JCheckBox c:checks){c.setOpaque(false);c.setFont(NORMAL);c.setForeground(DARK);}
        JSpinner quantity=new JSpinner(new SpinnerNumberModel(1,1,999,1));quantity.setFont(NORMAL);
        JPanel body=form();body.add(label(p.getNombre()+"  ·  "+price(p.getPrecio()),16,ESPRESSO,true));
        body.add(Box.createVerticalStrut(15));body.add(label("Complementos opcionales",13,MUTED,false));
        for(JCheckBox c:checks)body.add(c);
        body.add(Box.createVerticalStrut(10));body.add(field("Cantidad",quantity));
        int reply=JOptionPane.showConfirmDialog(this,body,"Personalizar producto",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        if(reply!=JOptionPane.OK_OPTION)return;
        ItemMenu item=p;
        if(checks[0].isSelected())item=new Complemento(item,"Leche adicional",new BigDecimal("1500"));
        if(checks[1].isSelected())item=new Complemento(item,"Crema",new BigDecimal("1000"));
        if(checks[2].isSelected())item=new Complemento(item,"Queso",new BigDecimal("2000"));
        cart.add(new LineaCarrito(p,item,(Integer)quantity.getValue()));
        showScreen("Nuevo pedido");
    }

    private void saveOrder() {
        runSafe(()->{
            List<DetallePedido> details=new ArrayList<>();
            for(LineaCarrito item:cart)details.add(new DetallePedido(item.product.getNombre(),item.decorated,item.quantity));
            if(details.isEmpty())throw new IllegalArgumentException("Agrega por lo menos un producto.");
            Pedido p=contexto.getPedidos().registrar(details);
            cart.clear();pedidoSeleccionado=p.getId();
            JOptionPane.showMessageDialog(this,"Pedido "+orderId(p.getId())+" registrado correctamente.\nTotal: "+price(p.getTotal()),"Pedido registrado",JOptionPane.INFORMATION_MESSAGE);
            showScreen("Pedidos");
        });
    }

    private void editPromotion() {
        JTextField name=input(24),value=input(12),start=input(7),end=input(7);
        start.setText("08:00");end.setText("18:00");
        JComboBox<String> kind=combo("Porcentaje (%)","Valor fijo (COP)");
        JPanel daysPanel=new JPanel(new GridLayout(2,4,8,6));daysPanel.setOpaque(false);
        JCheckBox[] checks=new JCheckBox[7];
        DayOfWeek[] dayValues=DayOfWeek.values();
        for(int i=0;i<7;i++){
            checks[i]=new JCheckBox(dayValues[i].getDisplayName(TextStyle.SHORT,new Locale("es","CO")));
            checks[i].setFont(SMALL);checks[i].setSelected(true);checks[i].setOpaque(false);daysPanel.add(checks[i]);
        }
        JPanel form=form();form.add(field("Nombre de la promoción",name));form.add(field("Tipo de descuento",kind));form.add(field("Valor del descuento",value));
        form.add(field("Días de la semana",daysPanel));
        JPanel hours=new JPanel(new FlowLayout(FlowLayout.LEFT,12,0));hours.setOpaque(false);hours.add(label("Inicio",12,MUTED,false));hours.add(start);hours.add(label("Fin",12,MUTED,false));hours.add(end);
        form.add(field("Horario (24 horas)",hours));
        while(true){
            int r=JOptionPane.showConfirmDialog(this,form,"Crear promoción",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
            if(r!=JOptionPane.OK_OPTION)return;
            try{
                Set<DayOfWeek> set=EnumSet.noneOf(DayOfWeek.class);
                for(int i=0;i<7;i++)if(checks[i].isSelected())set.add(dayValues[i]);
                BigDecimal v=new BigDecimal(value.getText().trim().replace(",","."));
                PoliticaDescuento policy=kind.getSelectedIndex()==0?new DescuentoPorcentaje(v):new DescuentoFijo(v);
                contexto.getPromociones().registrar(name.getText(),set,LocalTime.parse(start.getText().trim()),LocalTime.parse(end.getText().trim()),policy);
                showScreen("Promociones");return;
            }catch(RuntimeException e){warn("Revisa los campos, días y horarios. "+e.getMessage());}
        }
    }

    /** Pequeño cartel original pintado en Java2D para representar café, vinilos y rock.
     * No se utilizan capturas de Figma como fondo; los controles siguen siendo Swing. */
    private static final class RockPoster extends JPanel {
        RockPoster(){setBackground(ESPRESSO);setOpaque(true);}
        @Override protected void paintComponent(Graphics gr){
            super.paintComponent(gr);
            Graphics2D g=(Graphics2D)gr.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            int w=getWidth(),h=getHeight();
            g.setPaint(new GradientPaint(0,0,rgb("#3C231B"),w,h,rgb("#111315")));g.fillRect(0,0,w,h);
            g.setColor(new Color(212,136,68,72));g.fillOval(-45,-22,185,145);
            g.setColor(rgb("#101113"));g.fillOval(w/2-12,43,126,126);
            g.setColor(rgb("#3F4440"));g.setStroke(new BasicStroke(2f));
            for(int i=0;i<6;i++)g.drawOval(w/2-9+i*6,46+i*6,120-i*12,120-i*12);
            g.setColor(GOLD);g.fillOval(w/2+36,90,29,29);
            g.setColor(rgb("#992F26"));g.fillRoundRect(25,48,35,111,9,9);
            g.setColor(rgb("#E0B27B"));g.fillRoundRect(33,30,11,94,3,3);
            g.setColor(rgb("#222326"));g.setStroke(new BasicStroke(2.5f));
            for(int y=47;y<117;y+=11)g.drawLine(33,y,44,y);
            g.setColor(rgb("#F1E0BE"));g.fillOval(20,138,99,22);
            g.setColor(WHITE);g.fillRoundRect(36,130,66,43,13,13);
            g.setColor(rgb("#BE9B6D"));g.fillOval(44,131,51,13);
            g.setColor(rgb("#FFFFFF"));g.setStroke(new BasicStroke(5f));g.drawArc(92,137,19,25,270,220);
            g.setColor(new Color(28,28,28,212));g.fillRect(0,h-63,w,63);
            g.setColor(WHITE);g.setFont(new Font("Arial Narrow",Font.BOLD | Font.ITALIC,20));
            g.drawString("CAFÉ, VINILOS",13,h-36);g.drawString("Y BUEN ROCK.",13,h-14);
            g.dispose();
        }
    }

    private static final class BrandBanner extends JPanel {
        private final String slogan;
        BrandBanner(String slogan){
            this.slogan=slogan;
            setOpaque(true);setBackground(ESPRESSO);
            setPreferredSize(new Dimension(960,165));setMinimumSize(new Dimension(380,145));
            setMaximumSize(new Dimension(Integer.MAX_VALUE,175));
            setAlignmentX(Component.LEFT_ALIGNMENT);
        }
        @Override protected void paintComponent(Graphics gr){
            super.paintComponent(gr);
            Graphics2D g=(Graphics2D)gr.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            int w=getWidth(),h=getHeight();
            g.setColor(ESPRESSO);g.fillRect(0,0,w,h);
            g.setColor(GOLD);g.setFont(new Font("Segoe UI",Font.BOLD,11));
            g.drawString("CAFÉ & CO.  /  COFFEE + VINYL",22,29);
            g.setColor(WHITE);g.setFont(new Font("Arial Narrow",Font.BOLD|Font.ITALIC,w<720?22:30));
            String left=slogan;
            if(slogan.length()>26){int mid=slogan.indexOf(":");if(mid>0){g.drawString(slogan.substring(0,mid+1),22,74);left=slogan.substring(mid+1).trim();g.drawString(left,22,108);}}
            else g.drawString(left,22,85);
            int cx=Math.max(w-130,w*2/3), cy=h/2;
            g.setColor(rgb("#303338"));g.fillOval(cx-87,cy-77,156,156);
            g.setColor(rgb("#626262"));g.setStroke(new BasicStroke(2f));
            for(int i=0;i<6;i++)g.drawOval(cx-76+i*10,cy-66+i*10,136-20*i,136-20*i);
            g.setColor(CARAMEL);g.fillOval(cx-22,cy-12,45,45);
            g.setColor(GOLD);g.fillOval(cx-5,cy+5,12,12);
            g.setColor(WHITE);g.fillRoundRect(cx+52,cy+21,59,36,12,12);
            g.setColor(rgb("#A46A43"));g.fillOval(cx+59,cy+23,42,13);
            g.setColor(WHITE);g.setStroke(new BasicStroke(4f));g.drawArc(cx+102,cy+26,18,20,275,190);
            g.dispose();
        }
    }

    private static class LeftStack extends JPanel {
        LeftStack() { setOpaque(false); setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); }
        @Override protected void addImpl(Component child, Object constraints, int index) {
            if (child instanceof JComponent) ((JComponent) child).setAlignmentX(Component.LEFT_ALIGNMENT);
            super.addImpl(child,constraints,index);
        }
    }
    private static class ScrollPage extends JPanel implements Scrollable {
        @Override protected void addImpl(Component child, Object constraints, int index) {
            if (child instanceof JComponent) ((JComponent) child).setAlignmentX(Component.LEFT_ALIGNMENT);
            super.addImpl(child, constraints, index);
        }
        @Override public Dimension getPreferredScrollableViewportSize(){return getPreferredSize();}
        @Override public int getScrollableUnitIncrement(Rectangle r,int o,int d){return 18;}
        @Override public int getScrollableBlockIncrement(Rectangle r,int o,int d){return 110;}
        @Override public boolean getScrollableTracksViewportWidth(){return true;}
        @Override public boolean getScrollableTracksViewportHeight(){return false;}
    }
    private static JScrollPane table(Object[][] values, String[] headers) {
        DefaultTableModel m = model(headers);
        for (Object[] valuesRow : values) m.addRow(valuesRow);
        return scroll(styledTable(m));
    }
    private static JSeparator separator(){JSeparator s=new JSeparator();s.setForeground(LINE);s.setBackground(LINE);return s;}
    private static JPanel row(int gap) {
        JPanel p=new JPanel(new GridLayout(1,0,gap,0));p.setOpaque(false);p.setAlignmentX(Component.LEFT_ALIGNMENT);return p;
    }
    private static JPanel card() {return card(new BorderLayout());}
    private static JPanel card(LayoutManager layout) {JPanel p=rounded(layout,WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(LINE),new EmptyBorder(17,18,17,18)));
        return p;}
    private static JPanel rounded(LayoutManager layout,Color c){
        return new JPanel(layout){
            {setOpaque(false);setBackground(c);}
            @Override protected void paintComponent(Graphics graphics){
                Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(getBackground());g.fillRect(0,0,getWidth(),getHeight());
                g.dispose();super.paintComponent(graphics);
            }
        };
    }
    private static JPanel stat(String title,String number,String description) {
        JPanel p=card();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setPreferredSize(new Dimension(250,116));
        p.add(label(title,12,MUTED,true));p.add(Box.createVerticalStrut(5));p.add(label(number,23,ESPRESSO,true));
        p.add(Box.createVerticalGlue());p.add(label(description,11,MUTED,false));return p;
    }
    private static JPanel amountLine(String key,String val,boolean big) {
        JPanel p=new JPanel(new BorderLayout());p.setOpaque(false);
        p.add(label(key,big?14:12,MUTED,big),BorderLayout.WEST);
        p.add(label(val,big?18:13,ESPRESSO,true),BorderLayout.EAST);return p;
    }
    private static JLabel label(String val,int size,Color color,boolean bold) {
        JLabel l=new JLabel(val);l.setForeground(color);
        l.setFont(new Font(bold && size >= 18 ? "Arial Narrow" : "Segoe UI",bold?Font.BOLD:Font.PLAIN,size));return l;
    }
    private static JButton button(String val,Color background,Color foreground,Runnable action) {
        JButton b=new JButton(val){
            @Override protected void paintComponent(Graphics gr){
                Graphics2D g=(Graphics2D)gr.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(getModel().isPressed()?background.darker():getModel().isRollover()?mix(background,foreground,0.06f):background);
                g.fillRect(0,0,getWidth(),getHeight());
                if(background.equals(WHITE)) {g.setColor(LINE);g.drawRect(0,0,getWidth()-1,getHeight()-1);}
                g.dispose();super.paintComponent(gr);
            }
        };
        b.setFont(BOLD);b.setForeground(foreground);b.setContentAreaFilled(false);b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(11,15,11,15));b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if(action!=null)b.addActionListener(e->{try{action.run();}catch(RuntimeException ex){JOptionPane.showMessageDialog(b,ex.getMessage(),"Validación",JOptionPane.WARNING_MESSAGE);}});
        return b;
    }
    private static Color mix(Color a,Color b,float t){return new Color(Math.min(255,(int)(a.getRed()*(1-t)+b.getRed()*t)),Math.min(255,(int)(a.getGreen()*(1-t)+b.getGreen()*t)),Math.min(255,(int)(a.getBlue()*(1-t)+b.getBlue()*t)));}
    private static JTextField input(int cols){
        JTextField t=new JTextField(cols);t.setFont(NORMAL);t.setForeground(DARK);
        t.setBackground(WHITE);t.setCaretColor(ESPRESSO);t.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(MOCHA),new EmptyBorder(9,11,9,11)));
        return t;
    }
    private static JComboBox<String> combo(String... values){JComboBox<String> c=new JComboBox<>(values);styleCombo(c);return c;}
    private static void styleCombo(JComboBox<?> c){c.setFont(NORMAL);c.setBackground(WHITE);c.setForeground(DARK);c.setBorder(new EmptyBorder(5,5,5,5));}
    private static JPanel form(){JPanel p=new JPanel();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setBorder(new EmptyBorder(9,8,9,8));p.setBackground(WHITE);return p;}
    private static JPanel field(String label,JComponent comp){JPanel p=new JPanel();p.setOpaque(false);p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setBorder(new EmptyBorder(0,0,13,0));
        p.add(CafeteriaFigma.label(label,13,DARK,true));p.add(Box.createVerticalStrut(5));comp.setAlignmentX(Component.LEFT_ALIGNMENT);p.add(comp);return p;}
    private static DefaultTableModel model(Object[] headers){return new DefaultTableModel(headers,0){@Override public boolean isCellEditable(int r,int c){return false;}};}
    private static JTable styledTable(DefaultTableModel model){
        JTable t=new JTable(model);t.setFont(SMALL);t.setForeground(DARK);t.setRowHeight(44);
        t.setBackground(WHITE);t.setGridColor(LINE);t.setShowVerticalLines(false);t.setSelectionBackground(rgb("#E5CE8E"));
        t.setSelectionForeground(ESPRESSO);t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.getTableHeader().setBackground(ESPRESSO);t.getTableHeader().setForeground(WHITE);
        t.getTableHeader().setFont(BOLD);t.getTableHeader().setPreferredSize(new Dimension(0,44));
        t.getTableHeader().setReorderingAllowed(false);
        DefaultTableCellRenderer renderer=new DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable table,Object value,boolean selected,boolean focus,int r,int c){
                super.getTableCellRendererComponent(table,value,selected,focus,r,c);setBorder(new EmptyBorder(0,10,0,10));
                if(!selected)setBackground(r%2==0?WHITE:rgb("#E9E5DB"));
                if(value!=null){String s=value.toString();
                    if(s.equals("Entregado")||s.equals("Activa"))setForeground(GREEN);
                    else if(s.equals("Pendiente"))setForeground(rgb("#9E6925"));
                    else if(s.equals("Inactiva"))setForeground(TERRACOTTA);
                    else setForeground(DARK);
                }return this;
            }
        };
        t.setDefaultRenderer(Object.class,renderer);
        return t;
    }
    private static JScrollPane scroll(JTable t){JScrollPane s=new JScrollPane(t);s.setBackground(WHITE);s.setBorder(BorderFactory.createLineBorder(LINE));s.getViewport().setBackground(WHITE);return s;}
    private static DocumentListener listener(Runnable work){return new DocumentListener(){public void insertUpdate(DocumentEvent e){work.run();}public void removeUpdate(DocumentEvent e){work.run();}public void changedUpdate(DocumentEvent e){work.run();}};}
    private static int parseOrderId(String value){return Integer.parseInt(value.replace("#", "").trim());}
    private static int selectedId(JTable grid,DefaultTableModel m,int col,String message){
        int row=grid.getSelectedRow();if(row<0)throw new IllegalArgumentException(message);
        return Integer.parseInt(m.getValueAt(grid.convertRowIndexToModel(row),col).toString());
    }
    private void runSafe(Runnable runnable){try{runnable.run();}catch(RuntimeException e){warn(e.getMessage());}}
    private void warn(String msg){JOptionPane.showMessageDialog(this,msg,"Revisa la información",JOptionPane.WARNING_MESSAGE);}
    private boolean confirm(String msg){return JOptionPane.showConfirmDialog(this,msg,"Confirmación",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE)==JOptionPane.YES_OPTION;}
    private String price(BigDecimal amount){return money.format(amount).replace("COP","").trim();}
    private static String orderId(int id){return String.format("#%04d",id);}
    private static Color rgb(String value){return Color.decode(value);}
    private static Color stateColor(EstadoPedido s){return s==EstadoPedido.ENTREGADO?GREEN:s==EstadoPedido.PENDIENTE?CARAMEL:s==EstadoPedido.LISTO?SAGE:MOCHA;}
    private static String days(Set<DayOfWeek> days){
        if(days.size()==7)return "Todos los días";
        StringBuilder b=new StringBuilder();for(DayOfWeek d:DayOfWeek.values())if(days.contains(d)){
            if(b.length()>0)b.append(", ");b.append(d.getDisplayName(TextStyle.SHORT,new Locale("es","CO")));
        }return b.toString();
    }
    private static final class LineaCarrito {
        final Producto product;final ItemMenu decorated;int quantity;
        LineaCarrito(Producto p,ItemMenu i,int n){product=p;decorated=i;quantity=n;}
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(()->{
            UIManager.put("OptionPane.background",CREAM);
            UIManager.put("Panel.background",WHITE);
            UIManager.put("Button.font",NORMAL);
            new CafeteriaFigma().setVisible(true);
        });
    }
}
