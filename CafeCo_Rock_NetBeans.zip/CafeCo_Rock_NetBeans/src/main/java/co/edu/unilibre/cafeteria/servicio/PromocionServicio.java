package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.Promocion;
import co.edu.unilibre.cafeteria.modelo.ResultadoDescuento;
import co.edu.unilibre.cafeteria.promocion.PoliticaDescuento;
import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/** Administra promociones en memoria y selecciona solo la de mayor ahorro. */
public class PromocionServicio {
    private final Map<Integer, Promocion> promociones = new LinkedHashMap<Integer, Promocion>();
    private int siguienteId = 1;

    public Promocion registrar(String nombre, Set<DayOfWeek> dias, LocalTime inicio,
                              LocalTime fin, PoliticaDescuento politica) {
        Promocion nueva = new Promocion(siguienteId, nombre, dias, inicio, fin, politica);
        promociones.put(nueva.getId(), nueva);
        siguienteId++;
        return nueva;
    }

    public List<Promocion> listar() { return new ArrayList<Promocion>(promociones.values()); }

    public Promocion buscarPorId(int id) {
        Promocion p = promociones.get(id);
        if (p == null) throw new NoSuchElementException("No existe promoción con ID " + id + ".");
        return p;
    }

    public Promocion cambiarActiva(int id, boolean activa) {
        Promocion p = buscarPorId(id);
        p.setActiva(activa);
        return p;
    }

    public void eliminar(int id) {
        buscarPorId(id);
        promociones.remove(id);
    }

    public ResultadoDescuento mejorAplicable(BigDecimal subtotal, LocalDateTime fechaHora) {
        if (subtotal == null || subtotal.signum() < 0 || fechaHora == null)
            throw new IllegalArgumentException("Subtotal o fecha inválidos.");
        ResultadoDescuento mejor = ResultadoDescuento.ninguno();
        for (Promocion promocion : promociones.values()) {
            if (!promocion.aplicaEn(fechaHora)) continue;
            BigDecimal monto = promocion.descuento(subtotal);
            if (monto.compareTo(mejor.getMonto()) > 0) {
                mejor = new ResultadoDescuento(promocion.getId(), promocion.getNombre(), monto);
            }
        }
        return mejor;
    }
}
