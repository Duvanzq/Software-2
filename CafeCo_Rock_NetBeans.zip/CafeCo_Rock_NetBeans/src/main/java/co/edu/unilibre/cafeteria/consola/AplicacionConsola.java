package co.edu.unilibre.cafeteria.consola;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.DetallePedido;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.servicio.PedidoServicio;
import co.edu.unilibre.cafeteria.modelo.Complemento;
import co.edu.unilibre.cafeteria.modelo.ItemMenu;
import co.edu.unilibre.cafeteria.modelo.Producto;
import co.edu.unilibre.cafeteria.servicio.ProductoServicio;
import co.edu.unilibre.cafeteria.servicio.ContextoCafeteria;
import co.edu.unilibre.cafeteria.modelo.Promocion;
import co.edu.unilibre.cafeteria.modelo.ResumenCaja;
import co.edu.unilibre.cafeteria.promocion.PoliticaDescuento;
import co.edu.unilibre.cafeteria.promocion.DescuentoPorcentaje;
import co.edu.unilibre.cafeteria.promocion.DescuentoFijo;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.EnumSet;
import java.util.Set;
import java.math.BigDecimal;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Versión por consola: productos, personalización y pedidos en memoria. */
public class AplicacionConsola {
    private final Scanner entrada = new Scanner(System.in);
    private final ContextoCafeteria contexto = new ContextoCafeteria();
    private final ProductoServicio servicio = contexto.getProductos();
    private final PedidoServicio servicioPedidos = contexto.getPedidos();
    private final DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private final NumberFormat moneda = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));

    public static void main(String[] args) {
        new AplicacionConsola().iniciar();
    }

    private void iniciar() {
        boolean ejecutando = true;
        while (ejecutando) {
            mostrarMenu();
            String opcion = entrada.nextLine().trim();
            try {
                switch (opcion) {
                    case "1": registrar(); break;
                    case "2": mostrarProductos(servicio.listar()); break;
                    case "3": buscar(); break;
                    case "4": editar(); break;
                    case "5": eliminar(); break;
                    case "6": filtrarCategoria(); break;
                    case "7": personalizar(); break;
                    case "8": crearPedido(); break;
                    case "9": listarPedidos(); break;
                    case "10": consultarPedido(); break;
                    case "11": avanzarEstadoPedido(); break;
                    case "12": registrarPromocion(); break;
                    case "13": listarPromociones(); break;
                    case "14": cambiarPromocion(); break;
                    case "15": eliminarPromocion(); break;
                    case "16": cierreDeCaja(); break;
                    case "0":
                        ejecutando = false;
                        System.out.println("Hasta pronto.");
                        break;
                    default:
                        System.out.println("Opción no válida. Inténtalo otra vez.");
                }
            } catch (IllegalArgumentException | NoSuchElementException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void mostrarMenu() {
        System.out.println("\n====== CAFETERÍA - MENÚ DE PRODUCTOS ======");
        System.out.println("1. Registrar producto");
        System.out.println("2. Listar productos");
        System.out.println("3. Buscar producto por ID");
        System.out.println("4. Editar producto");
        System.out.println("5. Eliminar producto");
        System.out.println("6. Listar por categoría");
        System.out.println("7. Personalizar producto (demostración)");
        System.out.println("8. Crear pedido");
        System.out.println("9. Listar pedidos");
        System.out.println("10. Consultar pedido por ID");
        System.out.println("11. Avanzar estado de pedido");
        System.out.println("12. Registrar promoción por día y horario");
        System.out.println("13. Listar promociones");
        System.out.println("14. Activar / desactivar promoción");
        System.out.println("15. Eliminar promoción");
        System.out.println("16. Resumen de cierre de caja por fecha");
        System.out.println("0. Salir");
        System.out.print("Elige una opción: ");
    }

    private void registrar() {
        System.out.println("\n--- Nuevo producto ---");
        String nombre = leerTexto("Nombre: ");
        BigDecimal precio = leerPrecio("Precio (COP): ");
        CategoriaProducto categoria = leerCategoria();
        String descripcion = leerTexto("Descripción: ");
        Producto producto = servicio.registrar(nombre, precio, categoria, descripcion);
        System.out.println("Producto registrado con ID " + producto.getId() + ".");
    }

    private void buscar() {
        int id = leerId("ID del producto: ");
        mostrarProducto(servicio.buscarPorId(id));
    }

    private void editar() {
        int id = leerId("ID del producto que quieres editar: ");
        Producto anterior = servicio.buscarPorId(id);
        System.out.println("Deja un campo en blanco para conservar el valor actual.");
        String nombre = leerTextoOpcional("Nombre [" + anterior.getNombre() + "]: ", anterior.getNombre());
        BigDecimal precio = leerPrecioOpcional("Precio [" + anterior.getPrecio().toPlainString() + "]: ", anterior.getPrecio());
        CategoriaProducto categoria = leerCategoriaOpcional(anterior.getCategoria());
        String descripcion = leerTextoOpcional("Descripción [" + anterior.getDescripcion() + "]: ", anterior.getDescripcion());
        servicio.editar(id, nombre, precio, categoria, descripcion);
        System.out.println("Producto actualizado correctamente.");
    }

    private void eliminar() {
        int id = leerId("ID del producto que quieres eliminar: ");
        Producto producto = servicio.buscarPorId(id);
        mostrarProducto(producto);
        System.out.print("¿Confirmas la eliminación? (s/n): ");
        if ("s".equalsIgnoreCase(entrada.nextLine().trim())) {
            servicio.eliminar(id);
            System.out.println("Producto eliminado.");
        } else {
            System.out.println("Operación cancelada.");
        }
    }

    private void filtrarCategoria() {
        CategoriaProducto categoria = leerCategoria();
        System.out.println("\n--- Productos: " + categoria + " ---");
        mostrarProductos(servicio.listarPorCategoria(categoria));
    }

    /** Permite probar Decorator sin guardar un pedido. */
    private void personalizar() {
        int id = leerId("ID del producto a personalizar: ");
        Producto original = servicio.buscarPorId(id);
        ItemMenu personalizado = configurarComplementos(original);
        System.out.println("Precio personalizado final: " + moneda.format(personalizado.getPrecio()));
        System.out.println("Esta opción solo demuestra los complementos; usa la opción 8 para pedirlo.");
    }

    /** Se reutiliza tanto en la demostración como al registrar pedidos. */
    private ItemMenu configurarComplementos(Producto original) {
        Deque<ItemMenu> versiones = new ArrayDeque<ItemMenu>();
        versiones.push(original);
        while (true) {
            System.out.println("\n--- Personalización de " + original.getNombre() + " ---");
            System.out.println("Descripción: " + versiones.peek().getDescripcion());
            System.out.println("Precio unitario: " + moneda.format(versiones.peek().getPrecio()));
            System.out.println("1. Agregar leche adicional (+1500 COP)");
            System.out.println("2. Agregar crema (+1000 COP)");
            System.out.println("3. Agregar queso (+2000 COP)");
            System.out.println("4. Quitar el último complemento");
            System.out.println("0. Terminar personalización");
            System.out.print("Elige una opción: ");
            String opcion = entrada.nextLine().trim();
            switch (opcion) {
                case "1":
                    versiones.push(new Complemento(versiones.peek(),
                            "Leche adicional", new BigDecimal("1500")));
                    break;
                case "2":
                    versiones.push(new Complemento(versiones.peek(),
                            "Crema", new BigDecimal("1000")));
                    break;
                case "3":
                    versiones.push(new Complemento(versiones.peek(),
                            "Queso", new BigDecimal("2000")));
                    break;
                case "4":
                    if (versiones.size() > 1) {
                        versiones.pop();
                        System.out.println("Se quitó el último complemento.");
                    } else {
                        System.out.println("No hay complementos para quitar.");
                    }
                    break;
                case "0":
                    return versiones.peek();
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private void crearPedido() {
        if (servicio.listar().isEmpty()) {
            System.out.println("Primero debes registrar productos (opción 1).");
            return;
        }
        List<DetallePedido> detalles = new ArrayList<DetallePedido>();
        while (true) {
            System.out.println("\n====== NUEVO PEDIDO ======");
            mostrarProductos(servicio.listar());
            if (!detalles.isEmpty()) {
                System.out.println("--- Productos seleccionados ---");
                mostrarDetalles(detalles);
            }
            System.out.println("0. Confirmar pedido | C. Cancelar sin guardar");
            System.out.print("Escribe el ID del producto que quieres agregar: ");
            String opcion = entrada.nextLine().trim();
            if ("c".equalsIgnoreCase(opcion)) {
                System.out.println("Pedido cancelado.");
                return;
            }
            if ("0".equals(opcion)) {
                if (detalles.isEmpty()) {
                    System.out.println("Agrega al menos un producto antes de confirmar.");
                    continue;
                }
                Pedido creado = servicioPedidos.registrar(detalles);
                System.out.println("Pedido #" + creado.getId() + " creado correctamente.");
                mostrarPedido(creado);
                return;
            }
            try {
                int id = Integer.parseInt(opcion);
                Producto original = servicio.buscarPorId(id);
                ItemMenu personalizado = configurarComplementos(original);
                int cantidad = leerId("Cantidad de unidades: ");
                DetallePedido detalle = new DetallePedido(original.getNombre(), personalizado, cantidad);
                detalles.add(detalle);
                System.out.println("Producto agregado al pedido: " + detalle.getNombreProducto());
            } catch (NumberFormatException e) {
                System.out.println("Ingresa un ID numérico, 0 para confirmar o C para cancelar.");
            } catch (IllegalArgumentException | NoSuchElementException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void listarPedidos() {
        List<Pedido> pedidos = servicioPedidos.listar();
        if (pedidos.isEmpty()) {
            System.out.println("Todavía no hay pedidos registrados.");
            return;
        }
        System.out.println("\n--- Pedidos registrados ---");
        for (Pedido p : pedidos) {
            System.out.println("#" + p.getId() + " | " + formatoFecha.format(p.getFecha())
                    + " | " + p.getEstado() + " | " + moneda.format(p.getTotal()));
        }
    }

    private void consultarPedido() {
        int id = leerId("ID del pedido: ");
        mostrarPedido(servicioPedidos.buscarPorId(id));
    }

    private void avanzarEstadoPedido() {
        int id = leerId("ID del pedido cuyo estado quieres avanzar: ");
        Pedido pedido = servicioPedidos.buscarPorId(id);
        System.out.println("Estado actual: " + pedido.getEstado());
        try {
            servicioPedidos.avanzarEstado(id);
            System.out.println("Nuevo estado: " + pedido.getEstado());
        } catch (IllegalStateException e) {
            System.out.println("No se cambió el estado: " + e.getMessage());
        }
    }


    private void registrarPromocion() {
        System.out.println("\n--- Registrar promoción ---");
        String nombre = leerTexto("Nombre: ");
        Set<DayOfWeek> dias = leerDias();
        LocalTime inicio = leerHora("Inicio (HH:mm): ");
        LocalTime fin;
        do {
            fin = leerHora("Fin (HH:mm, puede cruzar medianoche): ");
            if (inicio.equals(fin)) System.out.println("Inicio y fin no pueden ser iguales.");
        } while (inicio.equals(fin));
        PoliticaDescuento politica;
        while (true) {
            String tipo = leerTexto("Tipo de descuento (1=porcentaje, 2=valor fijo COP): ");
            if ("1".equals(tipo)) {
                politica = new DescuentoPorcentaje(leerPrecio("Porcentaje (1 a 100): "));
                break;
            } else if ("2".equals(tipo)) {
                politica = new DescuentoFijo(leerPrecio("Descuento fijo COP: "));
                break;
            }
            System.out.println("Escribe 1 o 2.");
        }
        Promocion registrada = contexto.getPromociones().registrar(nombre, dias, inicio, fin, politica);
        System.out.println("Promoción #" + registrada.getId() + " creada y activa.");
    }

    private Set<DayOfWeek> leerDias() {
        while (true) {
            System.out.print("Días: 1=Lun ... 7=Dom (ej. 1,3,5; o * para todos): ");
            String texto = entrada.nextLine().trim();
            if ("*".equals(texto)) return EnumSet.allOf(DayOfWeek.class);
            EnumSet<DayOfWeek> dias = EnumSet.noneOf(DayOfWeek.class);
            try {
                for (String parte : texto.split(","))
                    dias.add(DayOfWeek.of(Integer.parseInt(parte.trim())));
                if (!dias.isEmpty()) return dias;
            } catch (RuntimeException e) {
                // Se repite la lectura cuando hay algún día incorrecto.
            }
            System.out.println("Indica números de 1 a 7 separados por comas, o *.");
        }
    }

    private LocalTime leerHora(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return LocalTime.parse(entrada.nextLine().trim());
            } catch (DateTimeParseException e) {
                System.out.println("Utiliza 24 horas, por ejemplo 08:00 o 17:30.");
            }
        }
    }

    private void listarPromociones() {
        List<Promocion> promociones = contexto.getPromociones().listar();
        if (promociones.isEmpty()) {
            System.out.println("No hay promociones registradas.");
            return;
        }
        for (Promocion p : promociones) {
            System.out.println("#" + p.getId() + " | " + p.getNombre()
                    + " | " + p.getRegla() + " | " + p.getDias()
                    + " | " + p.getInicio() + "-" + p.getFin()
                    + " | " + (p.isActiva() ? "Activa" : "Inactiva"));
        }
        System.out.println("Se aplica únicamente el descuento elegible de mayor valor por pedido.");
    }

    private void cambiarPromocion() {
        int id = leerId("ID de promoción: ");
        Promocion p = contexto.getPromociones().buscarPorId(id);
        contexto.getPromociones().cambiarActiva(id, !p.isActiva());
        System.out.println("Promoción " + (p.isActiva() ? "activada." : "desactivada."));
    }

    private void eliminarPromocion() {
        int id = leerId("ID de promoción para eliminar: ");
        contexto.getPromociones().eliminar(id);
        System.out.println("Promoción eliminada; no se modifican pedidos anteriores.");
    }

    private void cierreDeCaja() {
        System.out.print("Fecha AAAA-MM-DD (Enter = hoy): ");
        String texto = entrada.nextLine().trim();
        LocalDate fecha;
        try {
            fecha = texto.isEmpty() ? LocalDate.now(contexto.getReloj()) : LocalDate.parse(texto);
        } catch (DateTimeParseException e) {
            System.out.println("Fecha inválida. Usa AAAA-MM-DD.");
            return;
        }
        ResumenCaja resumen = contexto.getCaja().resumir(fecha);
        System.out.println("\n===== CIERRE DE CAJA " + resumen.getFecha() + " =====");
        System.out.println("Pedidos entregados: " + resumen.getPedidosEntregados());
        System.out.println("Ventas antes del descuento: " + moneda.format(resumen.getSubtotalBruto()));
        System.out.println("Descuentos: " + moneda.format(resumen.getDescuentos()));
        System.out.println("VENTA NETA: " + moneda.format(resumen.getVentasNetas()));
        System.out.println("No incluye pedidos pendientes, en preparación ni listos.");
    }

    private void mostrarPedido(Pedido pedido) {
        System.out.println("\n====== PEDIDO #" + pedido.getId() + " ======");
        System.out.println("Fecha: " + formatoFecha.format(pedido.getFecha()));
        System.out.println("Estado: " + pedido.getEstado());
        mostrarDetalles(pedido.getDetalles());
        System.out.println("Subtotal: " + moneda.format(pedido.getSubtotal()));
        System.out.println("Promoción: " + pedido.getNombrePromocion());
        System.out.println("Descuento: " + moneda.format(pedido.getDescuento()));
        System.out.println("TOTAL: " + moneda.format(pedido.getTotal()));
        if (pedido.getFechaEntrega() != null)
            System.out.println("Entregado: " + formatoFecha.format(pedido.getFechaEntrega()));
    }

    private void mostrarDetalles(List<DetallePedido> detalles) {
        for (DetallePedido d : detalles) {
            System.out.println(d.getCantidad() + " x " + d.getNombreProducto()
                    + " (" + moneda.format(d.getPrecioUnitario()) + " c/u) = "
                    + moneda.format(d.getSubtotal()));
            System.out.println("    " + d.getDescripcion());
        }
    }

    private void mostrarProductos(List<Producto> productos) {
        if (productos.isEmpty()) {
            System.out.println("No hay productos para mostrar.");
            return;
        }
        for (Producto p : productos) {
            mostrarProducto(p);
        }
    }

    private void mostrarProducto(Producto producto) {
        System.out.println("ID: " + producto.getId()
                + " | " + producto.getNombre()
                + " | " + producto.getCategoria()
                + " | " + moneda.format(producto.getPrecio())
                + " | " + producto.getDescripcion());
    }

    private String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = entrada.nextLine().trim();
            if (!valor.isEmpty()) return valor;
            System.out.println("Este campo no puede estar vacío.");
        }
    }

    private String leerTextoOpcional(String mensaje, String actual) {
        System.out.print(mensaje);
        String valor = entrada.nextLine().trim();
        return valor.isEmpty() ? actual : valor;
    }

    private BigDecimal leerPrecio(String mensaje) {
        while (true) {
            BigDecimal valor = convertirPrecio(leerTexto(mensaje));
            if (valor != null && valor.signum() > 0) return valor;
            System.out.println("Ingresa un precio numérico mayor que cero (ejemplo: 4500).");
        }
    }

    private BigDecimal leerPrecioOpcional(String mensaje, BigDecimal actual) {
        while (true) {
            System.out.print(mensaje);
            String texto = entrada.nextLine().trim();
            if (texto.isEmpty()) return actual;
            BigDecimal valor = convertirPrecio(texto);
            if (valor != null && valor.signum() > 0) return valor;
            System.out.println("Ingresa un precio válido mayor que cero o deja vacío.");
        }
    }

    private BigDecimal convertirPrecio(String texto) {
        try {
            // Se permite punto o coma como separador decimal, sin separadores de miles.
            return new BigDecimal(texto.replace(',', '.'));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private int leerId(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                int id = Integer.parseInt(entrada.nextLine().trim());
                if (id > 0) return id;
            } catch (NumberFormatException e) {
                // Volver a solicitar el dato.
            }
            System.out.println("Ingresa un ID entero positivo.");
        }
    }

    private CategoriaProducto leerCategoria() {
        while (true) {
            System.out.println("Categorías: 1. Bebida  2. Alimento  3. Otro");
            System.out.print("Elige la categoría: ");
            CategoriaProducto seleccion = categoriaDesdeTexto(entrada.nextLine().trim());
            if (seleccion != null) return seleccion;
            System.out.println("Selecciona 1, 2 o 3.");
        }
    }

    private CategoriaProducto leerCategoriaOpcional(CategoriaProducto actual) {
        while (true) {
            System.out.println("Categorías: 1. Bebida  2. Alimento  3. Otro");
            System.out.print("Categoría [" + actual + "] (Enter para conservar): ");
            String texto = entrada.nextLine().trim();
            if (texto.isEmpty()) return actual;
            CategoriaProducto seleccion = categoriaDesdeTexto(texto);
            if (seleccion != null) return seleccion;
            System.out.println("Selecciona 1, 2 o 3, o deja vacío.");
        }
    }

    private CategoriaProducto categoriaDesdeTexto(String texto) {
        switch (texto) {
            case "1": return CategoriaProducto.BEBIDA;
            case "2": return CategoriaProducto.ALIMENTO;
            case "3": return CategoriaProducto.OTRO;
            default: return null;
        }
    }
}
