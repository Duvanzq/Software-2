package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;

/** Valor congelado de la mejor promoción para un pedido. */
public final class ResultadoDescuento {
    private final int idPromocion; // 0 = sin promoción
    private final String nombrePromocion;
    private final BigDecimal monto;

    public ResultadoDescuento(int idPromocion, String nombrePromocion, BigDecimal monto) {
        if (idPromocion < 0 || nombrePromocion == null || monto == null || monto.signum() < 0)
            throw new IllegalArgumentException("Resultado de descuento inválido.");
        this.idPromocion = idPromocion;
        this.nombrePromocion = nombrePromocion;
        this.monto = monto;
    }

    public static ResultadoDescuento ninguno() {
        return new ResultadoDescuento(0, "Sin promoción", BigDecimal.ZERO);
    }
    public int getIdPromocion() { return idPromocion; }
    public String getNombrePromocion() { return nombrePromocion; }
    public BigDecimal getMonto() { return monto; }
}
