package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.DetallePedido;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.modelo.ResultadoDescuento;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/** Pedidos en memoria con cálculo automático y único de la mejor promoción. */
public class PedidoServicio {
    private final Map<Integer, Pedido> pedidos = new LinkedHashMap<Integer, Pedido>();
    private final PromocionServicio promociones;
    private final Clock reloj;
    private int siguienteId = 1;

    public PedidoServicio() { this(new PromocionServicio(), Clock.systemDefaultZone()); }

    public PedidoServicio(PromocionServicio promociones, Clock reloj) {
        if (promociones == null || reloj == null)
            throw new IllegalArgumentException("Promociones y reloj son obligatorios.");
        this.promociones = promociones;
        this.reloj = reloj;
    }

    public Pedido registrar(List<DetallePedido> detalles) {
        // Se valida antes de reservar el ID y se congela el descuento al registrar.
        if (detalles == null || detalles.isEmpty() || detalles.contains(null))
            throw new IllegalArgumentException("El pedido necesita al menos un producto válido.");
        LocalDateTime instante = LocalDateTime.now(reloj);
        BigDecimal subtotal = BigDecimal.ZERO;
        for (DetallePedido d : detalles) subtotal = subtotal.add(d.getSubtotal());
        ResultadoDescuento descuento = promociones.mejorAplicable(subtotal, instante);
        Pedido pedido = new Pedido(siguienteId, instante, detalles, descuento);
        pedidos.put(pedido.getId(), pedido);
        siguienteId++;
        return pedido;
    }

    public List<Pedido> listar() { return new ArrayList<Pedido>(pedidos.values()); }

    public Pedido buscarPorId(int id) {
        Pedido pedido = pedidos.get(id);
        if (pedido == null) throw new NoSuchElementException("No existe un pedido con ID " + id + ".");
        return pedido;
    }

    public Pedido avanzarEstado(int id) {
        Pedido pedido = buscarPorId(id);
        pedido.avanzarEstado(LocalDateTime.now(reloj));
        return pedido;
    }
}
