package co.edu.unilibre.cafeteria.modelo;

import java.math.BigDecimal;
import org.junit.Test;
import static org.junit.Assert.*;

public class ComplementoTest {
    @Test
    public void sumaExtrasSinModificarElProductoOriginal() {
        Producto cafe = new Producto(1, "Café", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA, "Café caliente");
        ItemMenu personalizado = new Complemento(cafe, "Leche adicional", new BigDecimal("1500"));
        personalizado = new Complemento(personalizado, "Crema", new BigDecimal("1000"));

        assertEquals(0, new BigDecimal("7000").compareTo(personalizado.getPrecio()));
        assertEquals("Café caliente + Leche adicional + Crema", personalizado.getDescripcion());
        assertEquals(0, new BigDecimal("4500").compareTo(cafe.getPrecio()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rechazaComplementoNegativo() {
        Producto cafe = new Producto(1, "Café", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA, "Café caliente");
        new Complemento(cafe, "Extra", new BigDecimal("-1"));
    }
}
