package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.DetallePedido;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.modelo.Producto;
import co.edu.unilibre.cafeteria.modelo.ResumenCaja;
import co.edu.unilibre.cafeteria.promocion.DescuentoPorcentaje;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.EnumSet;
import org.junit.Test;
import static org.junit.Assert.*;

public class CajaServicioTest {
    @Test
    public void cierreSoloSumaPedidosEntregadosYDescuentos() {
        Clock reloj = Clock.fixed(Instant.parse("2026-11-23T15:00:00Z"), ZoneId.of("America/Bogota"));
        PromocionServicio promociones = new PromocionServicio();
        promociones.registrar("10%", EnumSet.of(DayOfWeek.MONDAY), LocalTime.of(8,0),
                LocalTime.of(18,0), new DescuentoPorcentaje(new BigDecimal("10")));
        PedidoServicio pedidos = new PedidoServicio(promociones, reloj);
        Producto cafe = new Producto(1,"Café",new BigDecimal("5000"),CategoriaProducto.BEBIDA,"Caliente");
        Pedido entregado = pedidos.registrar(Arrays.asList(new DetallePedido("Café", cafe, 2)));
        pedidos.registrar(Arrays.asList(new DetallePedido("Café", cafe, 1))); // aún pendiente
        for (int i=0; i<3; i++) pedidos.avanzarEstado(entregado.getId());
        ResumenCaja r = new CajaServicio(pedidos).resumir(LocalDate.of(2026,11,23));
        assertEquals(1, r.getPedidosEntregados());
        assertEquals(0,new BigDecimal("10000").compareTo(r.getSubtotalBruto()));
        assertEquals(0,new BigDecimal("1000").compareTo(r.getDescuentos()));
        assertEquals(0,new BigDecimal("9000").compareTo(r.getVentasNetas()));
        assertEquals(0,new CajaServicio(pedidos).resumir(LocalDate.of(2026,11,24)).getPedidosEntregados());
    }

    @Test
    public void precioYPromocionSeCongelanLuegoDelRegistro() {
        Clock reloj = Clock.fixed(Instant.parse("2026-11-23T15:00:00Z"), ZoneId.of("America/Bogota"));
        ContextoCafeteria ctx = new ContextoCafeteria(reloj);
        ctx.getPromociones().registrar("50%", EnumSet.of(DayOfWeek.MONDAY),
                LocalTime.of(8,0), LocalTime.of(12,0), new DescuentoPorcentaje(new BigDecimal("50")));
        Producto cafe = ctx.getProductos().registrar("Café", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA,"Café caliente");
        Pedido p = ctx.getPedidos().registrar(Arrays.asList(new DetallePedido(cafe.getNombre(),cafe,2)));
        ctx.getProductos().editar(cafe.getId(),"Café",new BigDecimal("10000"),
                CategoriaProducto.BEBIDA,"Otro precio");
        ctx.getPromociones().eliminar(1);
        assertEquals(0,new BigDecimal("4500").compareTo(p.getTotal()));
        assertEquals("50%",p.getNombrePromocion());
    }
}
