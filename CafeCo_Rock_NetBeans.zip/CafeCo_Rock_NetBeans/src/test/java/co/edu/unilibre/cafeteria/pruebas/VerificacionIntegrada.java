package co.edu.unilibre.cafeteria.pruebas;

import co.edu.unilibre.cafeteria.modelo.*;
import co.edu.unilibre.cafeteria.servicio.*;
import co.edu.unilibre.cafeteria.promocion.*;
import java.math.*;
import java.time.*;
import java.util.*;
public class VerificacionIntegrada {
    static int total=0;
    static void ok(boolean result, String message) {
        total++;
        if(!result) throw new AssertionError(message);
    }
    static void eq(String expected, BigDecimal actual) { ok(new BigDecimal(expected).compareTo(actual)==0, expected+" != "+actual); }
    public static void main(String[] args) {
        Clock lunes = Clock.fixed(Instant.parse("2026-11-23T15:00:00Z"), ZoneId.of("America/Bogota"));
        ContextoCafeteria ctx = new ContextoCafeteria(lunes);
        Producto cafe = ctx.getProductos().registrar("Café",new BigDecimal("4500"),CategoriaProducto.BEBIDA,"Caliente");
        Producto arepa = ctx.getProductos().registrar("Arepa",new BigDecimal("6000"),CategoriaProducto.ALIMENTO,"Queso");
        ok(ctx.getProductos().listarPorCategoria(CategoriaProducto.BEBIDA).size()==1,"categoria");
        ItemMenu personalizado = new Complemento(new Complemento(cafe,"Leche",new BigDecimal("1500")), "Crema",new BigDecimal("1000"));
        eq("7000",personalizado.getPrecio()); eq("4500",cafe.getPrecio());
        Promocion p1 = ctx.getPromociones().registrar("10%",EnumSet.of(DayOfWeek.MONDAY),LocalTime.of(9,0),LocalTime.of(13,0),new DescuentoPorcentaje(new BigDecimal("10")));
        Promocion p2 = ctx.getPromociones().registrar("2000",EnumSet.of(DayOfWeek.MONDAY),LocalTime.of(9,0),LocalTime.of(13,0),new DescuentoFijo(new BigDecimal("2000")));
        Pedido p = ctx.getPedidos().registrar(Arrays.asList(new DetallePedido("Café",personalizado,2),new DetallePedido("Arepa",arepa,1)));
        eq("20000",p.getSubtotal()); eq("2000",p.getDescuento()); eq("18000",p.getTotal());
        ok(p.getIdPromocion()==p1.getId(),"empate: primera promo gana");
        ctx.getProductos().editar(1,"Café caro",new BigDecimal("55000"),CategoriaProducto.BEBIDA,"Caro");
        ctx.getPromociones().eliminar(p1.getId());
        eq("18000",p.getTotal());
        ctx.getPromociones().cambiarActiva(p2.getId(),false);
        Pedido q = ctx.getPedidos().registrar(Arrays.asList(new DetallePedido("Arepa",arepa,1)));
        eq("6000",q.getTotal());
        ctx.getPedidos().avanzarEstado(p.getId());
        ok(p.getEstado()==EstadoPedido.EN_PREPARACION,"prep");
        ctx.getPedidos().avanzarEstado(p.getId());
        ctx.getPedidos().avanzarEstado(p.getId());
        ok(p.getFechaEntrega()!=null,"delivery timestamp");
        ResumenCaja caja = ctx.getCaja().resumir(LocalDate.of(2026,11,23));
        ok(caja.getPedidosEntregados()==1,"caja no sumar pendientes");
        eq("20000",caja.getSubtotalBruto()); eq("2000",caja.getDescuentos()); eq("18000",caja.getVentasNetas());
        ok(ctx.getCaja().resumir(LocalDate.of(2026,11,24)).getPedidosEntregados()==0,"otra fecha");
        try {ctx.getPedidos().avanzarEstado(p.getId()); throw new AssertionError("over delivered");} catch(IllegalStateException e) { total++; }
        try {ctx.getProductos().registrar("", BigDecimal.ONE,CategoriaProducto.ALIMENTO,"x"); throw new AssertionError("empty name");} catch(IllegalArgumentException e) { total++; }
        Promocion noche = ctx.getPromociones().registrar("Noche",EnumSet.of(DayOfWeek.FRIDAY),LocalTime.of(22,0),LocalTime.of(2,0),new DescuentoFijo(new BigDecimal("1000")));
        ok(noche.aplicaEn(LocalDateTime.of(2026,11,28,1,0)),"overnight");
        ok(!noche.aplicaEn(LocalDateTime.of(2026,11,28,2,0)),"end exclusive");
        eq("156",new DescuentoPorcentaje(new BigDecimal("10")).calcularDescuento(new BigDecimal("1555")));
        System.out.println("PASS "+total+" verificaciones");
    }
}
