package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.Producto;
import java.math.BigDecimal;
import java.util.NoSuchElementException;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductoServicioTest {
    private ProductoServicio servicio;

    @Before
    public void preparar() {
        servicio = new ProductoServicio();
    }

    @Test
    public void registraYConsultaProducto() {
        Producto creado = servicio.registrar("Café", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA, "Café caliente");
        assertEquals(1, creado.getId());
        assertEquals("Café", servicio.buscarPorId(1).getNombre());
        assertEquals(1, servicio.listar().size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void rechazaNombreVacio() {
        servicio.registrar(" ", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA, "Café caliente");
    }

    @Test(expected = IllegalArgumentException.class)
    public void rechazaPrecioNegativo() {
        servicio.registrar("Café", new BigDecimal("-1"),
                CategoriaProducto.BEBIDA, "Café caliente");
    }

    @Test
    public void editaConservandoId() {
        Producto creado = servicio.registrar("Tinto", new BigDecimal("2500"),
                CategoriaProducto.BEBIDA, "Negro");
        Producto editado = servicio.editar(creado.getId(), "Tinto grande",
                new BigDecimal("3500"), CategoriaProducto.BEBIDA, "Grande");
        assertEquals(creado.getId(), editado.getId());
        assertEquals(0, new BigDecimal("3500").compareTo(servicio.buscarPorId(creado.getId()).getPrecio()));
    }

    @Test
    public void filtraProductosPorCategoria() {
        servicio.registrar("Café", new BigDecimal("4500"), CategoriaProducto.BEBIDA, "Caliente");
        servicio.registrar("Arepa", new BigDecimal("6000"), CategoriaProducto.ALIMENTO, "Con queso");
        assertEquals(1, servicio.listarPorCategoria(CategoriaProducto.BEBIDA).size());
        assertEquals("Café", servicio.listarPorCategoria(CategoriaProducto.BEBIDA).get(0).getNombre());
    }

    @Test(expected = NoSuchElementException.class)
    public void eliminaProducto() {
        Producto creado = servicio.registrar("Jugo", new BigDecimal("5000"),
                CategoriaProducto.BEBIDA, "Natural");
        servicio.eliminar(creado.getId());
        servicio.buscarPorId(creado.getId());
    }

    @Test
    public void noConsumeIdSiElRegistroFalla() {
        try {
            servicio.registrar("", new BigDecimal("2000"), CategoriaProducto.BEBIDA, "Sin nombre");
            fail("Se esperaba validación del nombre");
        } catch (IllegalArgumentException esperado) {
            // El siguiente producto válido debe recibir el ID 1.
        }
        Producto producto = servicio.registrar("Agua", new BigDecimal("2000"),
                CategoriaProducto.BEBIDA, "Botella");
        assertEquals(1, producto.getId());
    }
}
