package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.Complemento;
import co.edu.unilibre.cafeteria.modelo.DetallePedido;
import co.edu.unilibre.cafeteria.modelo.EstadoPedido;
import co.edu.unilibre.cafeteria.modelo.ItemMenu;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.modelo.Producto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class PedidoServicioTest {
    private final Producto cafe = new Producto(1, "Café", new BigDecimal("4500"),
            CategoriaProducto.BEBIDA, "Café caliente");

    @Test
    public void totalIncluyeComplementosYCantidades() {
        ItemMenu conLeche = new Complemento(cafe, "Leche", new BigDecimal("1500"));
        DetallePedido cafeDoble = new DetallePedido("Café", conLeche, 2);
        DetallePedido cafeSolo = new DetallePedido("Café", cafe, 1);
        Pedido pedido = new PedidoServicio().registrar(Arrays.asList(cafeDoble, cafeSolo));
        assertEquals(0, new BigDecimal("16500").compareTo(pedido.getTotal()));
        assertEquals(EstadoPedido.PENDIENTE, pedido.getEstado());
        assertEquals(1, pedido.getId());
    }

    @Test
    public void avanzaEstadoPasoAPaso() {
        PedidoServicio servicio = new PedidoServicio();
        Pedido pedido = servicio.registrar(Arrays.asList(new DetallePedido("Café", cafe, 1)));
        assertEquals(EstadoPedido.EN_PREPARACION, servicio.avanzarEstado(pedido.getId()).getEstado());
        assertEquals(EstadoPedido.LISTO, servicio.avanzarEstado(pedido.getId()).getEstado());
        assertEquals(EstadoPedido.ENTREGADO, servicio.avanzarEstado(pedido.getId()).getEstado());
    }

    @Test(expected = IllegalStateException.class)
    public void noAvanzaMasAllaDeEntregado() {
        PedidoServicio servicio = new PedidoServicio();
        Pedido p = servicio.registrar(Arrays.asList(new DetallePedido("Café", cafe, 1)));
        servicio.avanzarEstado(p.getId());
        servicio.avanzarEstado(p.getId());
        servicio.avanzarEstado(p.getId());
        servicio.avanzarEstado(p.getId());
    }

    @Test(expected = IllegalArgumentException.class)
    public void rechazaPedidoSinDetalles() {
        new PedidoServicio().registrar(new ArrayList<DetallePedido>());
    }

    @Test(expected = IllegalArgumentException.class)
    public void rechazaCantidadCero() {
        new DetallePedido("Café", cafe, 0);
    }

    @Test
    public void conservaPrecioAunqueCambieElCatalogoYProtegeLista() {
        ProductoServicio catalogo = new ProductoServicio();
        Producto original = catalogo.registrar("Café", new BigDecimal("4500"),
                CategoriaProducto.BEBIDA, "Café caliente");
        Pedido p = new PedidoServicio().registrar(Arrays.asList(new DetallePedido(original.getNombre(), original, 1)));
        catalogo.editar(original.getId(), "Café", new BigDecimal("9999"),
                CategoriaProducto.BEBIDA, "Café caro");
        catalogo.eliminar(original.getId());
        assertEquals(0, new BigDecimal("4500").compareTo(p.getTotal()));
        try {
            p.getDetalles().clear();
            fail("No se puede modificar la lista de detalles de un pedido guardado.");
        } catch (UnsupportedOperationException esperado) {
            // Listas de los pedidos son inmutables desde el exterior.
        }
    }

    @Test
    public void noConsumeIdSiRegistroEsInvalido() {
        PedidoServicio servicio = new PedidoServicio();
        try {
            servicio.registrar(null);
            fail("Se esperaba que rechazara el pedido nulo.");
        } catch (IllegalArgumentException esperado) {
            // No se consume el ID 1.
        }
        Pedido p = servicio.registrar(Arrays.asList(new DetallePedido("Café", cafe, 1)));
        assertEquals(1, p.getId());
    }
}
