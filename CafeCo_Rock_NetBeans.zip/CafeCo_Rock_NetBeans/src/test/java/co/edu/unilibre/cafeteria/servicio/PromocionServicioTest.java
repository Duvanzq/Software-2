package co.edu.unilibre.cafeteria.servicio;

import co.edu.unilibre.cafeteria.modelo.Promocion;
import co.edu.unilibre.cafeteria.promocion.DescuentoFijo;
import co.edu.unilibre.cafeteria.promocion.DescuentoPorcentaje;
import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.EnumSet;
import org.junit.Test;
import static org.junit.Assert.*;

public class PromocionServicioTest {
    @Test
    public void aplicaMayorDescuentoSinAcumularPromociones() {
        PromocionServicio servicio = new PromocionServicio();
        servicio.registrar("10%", EnumSet.of(DayOfWeek.MONDAY), LocalTime.of(8,0),
                LocalTime.of(18,0), new DescuentoPorcentaje(new BigDecimal("10")));
        servicio.registrar("Dos mil", EnumSet.of(DayOfWeek.MONDAY), LocalTime.of(8,0),
                LocalTime.of(18,0), new DescuentoFijo(new BigDecimal("2000")));
        assertEquals(0, new BigDecimal("2000").compareTo(
                servicio.mejorAplicable(new BigDecimal("15000"), LocalDateTime.of(2026,11,23,11,0)).getMonto()));
        assertEquals(0, new BigDecimal("3000").compareTo(
                servicio.mejorAplicable(new BigDecimal("30000"), LocalDateTime.of(2026,11,23,11,0)).getMonto()));
    }

    @Test
    public void horarioInicioInclusivoYFinExclusivo() {
        PromocionServicio servicio = new PromocionServicio();
        servicio.registrar("Promo", EnumSet.of(DayOfWeek.MONDAY), LocalTime.of(9,0),
                LocalTime.of(12,0), new DescuentoFijo(new BigDecimal("1000")));
        assertEquals(0, new BigDecimal("1000").compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), LocalDateTime.of(2026,11,23,9,0)).getMonto()));
        assertEquals(0, BigDecimal.ZERO.compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), LocalDateTime.of(2026,11,23,12,0)).getMonto()));
        assertEquals(0, BigDecimal.ZERO.compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), LocalDateTime.of(2026,11,24,10,0)).getMonto()));
    }

    @Test
    public void horarioNocturnoRespetaElDiaDeInicio() {
        PromocionServicio servicio = new PromocionServicio();
        servicio.registrar("Viernes noche", EnumSet.of(DayOfWeek.FRIDAY), LocalTime.of(22,0),
                LocalTime.of(2,0), new DescuentoFijo(new BigDecimal("1000")));
        assertEquals(0, new BigDecimal("1000").compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), LocalDateTime.of(2026,11,28,1,0)).getMonto()));
        assertEquals(0, BigDecimal.ZERO.compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), LocalDateTime.of(2026,11,28,2,0)).getMonto()));
    }

    @Test
    public void desactivacionEliminacionYLimiteDeDescuento() {
        PromocionServicio servicio = new PromocionServicio();
        Promocion p = servicio.registrar("Regalo", EnumSet.allOf(DayOfWeek.class),
                LocalTime.MIN, LocalTime.of(23,59), new DescuentoFijo(new BigDecimal("99999")));
        LocalDateTime fecha = LocalDateTime.of(2026,11,23,10,0);
        assertEquals(0, new BigDecimal("5000").compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), fecha).getMonto()));
        servicio.cambiarActiva(p.getId(), false);
        assertEquals(0, BigDecimal.ZERO.compareTo(
                servicio.mejorAplicable(new BigDecimal("5000"), fecha).getMonto()));
        servicio.eliminar(p.getId());
        assertEquals(0, servicio.listar().size());
    }

    @Test(expected=IllegalArgumentException.class)
    public void rechazaPorcentajeSuperiorACien() {
        new DescuentoPorcentaje(new BigDecimal("101"));
    }

    @Test
    public void redondeaPorcentajeAlPeso() {
        assertEquals(0, new BigDecimal("156").compareTo(
                new DescuentoPorcentaje(new BigDecimal("10"))
                        .calcularDescuento(new BigDecimal("1555"))));
    }
}
