@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CafeCo Rock - Crear EXE portable para Windows

echo =====================================================
echo       CafeCo Rock - Crear ejecutable portable de Windows

echo =====================================================
echo.

if not exist "app\CafeCo.jar" (
    echo ERROR: No se encontro app\CafeCo.jar
    echo Extrae TODO el archivo ZIP antes de ejecutar este script.
    pause
    exit /b 1
)

set "JPACKAGE="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\jpackage.exe" set "JPACKAGE=%JAVA_HOME%\bin\jpackage.exe"
if not defined JPACKAGE (
    for /f "delims=" %%J in ('where jpackage 2^>nul') do if not defined JPACKAGE set "JPACKAGE=%%J"
)

if not defined JPACKAGE (
    echo ERROR: No se encontro jpackage.
    echo Instala un JDK para Windows 17 o superior (recomendado JDK 21).
    echo Cierra y vuelve a abrir esta ventana, o configura JAVA_HOME
    echo con la ruta de tu JDK. El JRE por si solo no es suficiente.
    pause
    exit /b 1
)

if exist "dist\CafeCo" (
    echo Eliminando la version portable anterior...
    rmdir /s /q "dist\CafeCo"
    if exist "dist\CafeCo" (
        echo ERROR: No se pudo borrar dist\CafeCo. Cierra la aplicacion e intentalo.
        pause
        exit /b 1
    )
)

if not exist "dist" mkdir "dist"

echo Empaquetando con:
echo "%JPACKAGE%"
"%JPACKAGE%" --version

echo.
echo Creando CafeCo.exe y la carpeta con Java incluido...
"%JPACKAGE%" ^
  --type app-image ^
  --name CafeCo ^
  --app-version 2.0.0 ^
  --vendor "Cafe & Co" ^
  --description "Cafeteria / cafe, vinilos y rock" ^
  --input "%CD%\app" ^
  --main-jar CafeCo.jar ^
  --main-class co.edu.unilibre.cafeteria.grafica.CafeteriaFigma ^
  --icon "%CD%\CafeCo.ico" ^
  --dest "%CD%\dist"

if errorlevel 1 (
    echo.
    echo ERROR: jpackage no pudo crear el ejecutable.
    echo Revisa los mensajes anteriores. Comprueba que tu JDK sea de Windows.
    pause
    exit /b 1
)

if not exist "dist\CafeCo\CafeCo.exe" (
    echo ERROR: No se encontro el ejecutable tras el empaquetado.
    pause
    exit /b 1
)

echo.
echo =====================================================
echo                  LISTO

echo =====================================================
echo Ejecutable: %CD%\dist\CafeCo\CafeCo.exe

echo IMPORTANTE: Para llevar CafeCo a otro PC,
echo copia la carpeta COMPLETA dist\CafeCo.
echo El archivo .exe no se ejecuta solo sin su carpeta runtime.
echo.
explorer "%CD%\dist\CafeCo"
pause
endlocal
