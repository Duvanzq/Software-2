# Café & Co. — Coffee / Vinyl / Rock 'n' Roll

Proyecto de **Ingeniería de Software II** hecho en Java Swing / Maven para **Apache NetBeans**. Diseño actualizado siguiendo el archivo de Figma del usuario: [Café & Co. · Gestión de cafetería](https://www.figma.com/design/eyfhUH8rAQDfTdz7i94Lil/Caf%C3%A9---Co.-%C2%B7-Gesti%C3%B3n-de-cafeter%C3%ADa?node-id=0-1&m=dev).

## Abrir con NetBeans

1. Extrae el ZIP completo. En NetBeans → **File > Open Project**, selecciona la carpeta `CafeCo_Rock_NetBeans` que contiene `pom.xml`.
2. En **Source Packages**, abre `co.edu.unilibre.cafeteria.grafica.CafeteriaFigma`.
3. Haz **Run File** (`Shift + F6`) o **Run Project**. La clase principal está configurada en `pom.xml`.
4. Requiere **JDK 8 o superior**; se recomienda JDK 17 o JDK 21. La primera ejecución Maven podría descargar JUnit de internet para las pruebas.

## Nuevo diseño

Se incorporaron la paleta y la identidad visual del nuevo Figma: negro espresso `#191A1C`, crema `#EEEADF`, dorado `#D1AA4A`, rojo `#B43A2C`, verde `#326455`, tipografía de estilo condensado e itálico, navegación lateral dorada, tablas con cabecera negra, indicadores, botones y carteles sobre café, vinilos y rock.

**Nota sobre fidelidad:** la interfaz utiliza componentes Java Swing reales. La fotografía del Figma fue sustituida en esta versión por **ilustraciones originales pintadas con Java2D** (una taza y vinilos), para no integrar imágenes de terceros sin acceso a los archivos originales. Esto evita usar capturas como falsos elementos de interfaz. El resultado es una adaptación visual, no una réplica píxel a píxel.

Pantallas: **Inicio, Productos, Nuevo pedido, Pedidos, Promociones y Cierre de caja**. Se conservan los formularios modales y las validaciones, los estados de pedidos, los descuentos y los cálculos de caja. Se excluyen combos y notificaciones según el alcance del parcial.

## Datos en memoria

La app inicia sin datos de negocio precargados. Registra productos y luego crea pedidos. Los datos desaparecen al cerrar la aplicación. Las capturas `docs/rock_*.png` incluyen únicamente productos de ejemplo usados durante las pruebas de interfaz.

## Formulario de NetBeans

Esta versión es un **proyecto NetBeans completo**, editable como **código Java Swing**, pero la clase `CafeteriaFigma.java` **no tiene un archivo `.form` del GUI Builder**. Para editar visualmente con arrastrar y soltar sería necesario migrar los paneles a los formularios administrados por NetBeans; no se debe convertir el `.java` renombrando su extensión.

## Ejecutable para Windows

Dentro de `paquete_windows/` se incluye:

- `CafeCo.exe`: lanzador Windows 64-bit con el JAR integrado. Necesita Java 8+ instalado y accesible por `JAVA_HOME` o `PATH`.
- `app/CafeCo.jar`: JAR compilado con Java 8 como versión objetivo y entrada a la interfaz actual.
- `CREAR_PORTABLE_CON_JAVA.bat`: en **Windows**, con JDK 17+ y `jpackage`, genera `dist/CafeCo/CafeCo.exe` con su propio Java incluido; debe conservarse toda la carpeta generada.
- `CafeCo.ico`: icono original que utiliza `jpackage`.
- `LEEME_EJECUTABLE.txt`: instrucciones en español.

**El `.exe` fue compilado cruzadamente desde Linux como PE32+ de Windows; no fue ejecutado en Windows aquí.** La interfaz Swing sí se abrió y probó bajo un servidor gráfico virtual Linux.

## Estructura

```text
src/main/java/co/edu/unilibre/cafeteria/
  consola/           Aplicación de consola (requisito RNF07)
  grafica/           CafeteriaFigma.java, interfaz principal
  modelo/            Producto, Pedido, Complemento, Promoción, etc.
  servicio/          Gestión de negocio y datos en memoria
  promocion/         Estrategias de descuento
src/main/resources/  Icono integrado
src/test/java/       Pruebas unitarias y verificación de integración
paquete_windows/     EXE, JAR, icono, generador portable
```

## Verificaciones

- Compilación de todas las clases principales con `javac --release 8 -encoding UTF-8` en OpenJDK 21.
- **21 verificaciones de integración superadas** con `VerificacionIntegrada`.
- Construcción y ejecución gráfica de las pantallas principales bajo Xvfb; se generaron capturas en `docs/`.
- Comprobación de que `CafeCo.exe` es un ejecutable PE32+ de Windows de 64 bits (GUI) mediante `file`.
- Pendiente de verificación: abrir `CafeCo.exe` en Windows 11, generación de `jpackage` en Windows y `mvn test` dentro de NetBeans (Maven CLI no disponible en el entorno actual).

No se requiere ni se incluye base de datos. No se modificó el archivo original de Figma.
