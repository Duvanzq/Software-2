# Sistema de Gestión de Cafetería — Proyecto completo (antes del diseño UX)

**Universidad Libre — Ingeniería de Software II — Parcial 3**  
**Lenguaje:** Java 8 o superior | **IDE:** Apache NetBeans | **Construcción:** Maven  
**Persistencia:** memoria local en ejecución, sin MySQL, XAMPP ni archivos de datos.  
**Interfaces disponibles:** consola **y** interfaz funcional Swing (básica; el rediseño UX se deja para la siguiente etapa).

## 1. Cómo abrir en NetBeans (Windows)

1. Extraer `Cafeteria_Java_Completo.zip` a una carpeta, por ejemplo `Documentos\Cafeteria_Java_Completo`.
2. NetBeans → **File → Open Project** (**Archivo → Abrir proyecto**) y seleccionar **la carpeta que contiene `pom.xml`**, no `src`.
3. Esperar a que Maven complete la importación. Recomendamos **JDK 17 o 21** (el código es compatible con Java 8). Para el primer uso, Maven puede necesitar conexión a internet para las dependencias de pruebas.
4. En `Source Packages`, ejecutar **una** de las siguientes clases con clic derecho → **Run File** (`Shift + F6`):
   - `co.edu.unilibre.cafeteria.consola.AplicacionConsola` → menú por consola.
   - `co.edu.unilibre.cafeteria.grafica.AplicacionGrafica` → ventana gráfica con pestañas.
5. Para correr todas las pruebas unitarias: clic derecho sobre el proyecto → **Test**, o terminal en su directorio: `mvn test`.

> También puedes ejecutar `mvn exec:java` para iniciar la **consola**. Para abrir Swing por Maven: `mvn exec:java -Dexec.mainClass=co.edu.unilibre.cafeteria.grafica.AplicacionGrafica`.

Si NetBeans abre una carpeta vacía, probablemente seleccionaste la carpeta `src` en vez del directorio del `pom.xml`.

## 2. Qué está implementado

| Req. del PDF | Cobertura | Dónde está |
|---|---|---|
| RF01, RF02 | Registrar, consultar, modificar, eliminar productos | `ProductoServicio`, pestaña Productos, consola 1-5 |
| RF03 | Categorías de producto y consulta por categoría | `CategoriaProducto`, `ProductoServicio`, consola 6; Swing las muestra |
| RF04, RF05 | Personalización y recálculo de precio, incluyendo quitar el último extra | `ItemMenu`, `Complemento` (Decorator), consola 7/8 y Swing en pedido |
| RF07 | Pedidos de 1 o más productos, cantidades y personalización | `PedidoServicio`, `DetallePedido`, consola 8 |
| RF08 | Subtotal, mayor descuento vigente, total neto | `Pedido`, `PromocionServicio` |
| RF09 | Avance pendiente → preparación → listo → entregado | `EstadoPedido`, `PedidoServicio`, consola 11 y Swing |
| RF11 | Crear promociones con reglas por día y horario | `PromocionServicio`, `Promocion`, consola 12 |
| RF12 | Aplicación automática al confirmar el pedido | `PromocionServicio.mejorAplicable` y `PedidoServicio.registrar` |
| RF13 | Lista y detalle de pedidos | `PedidoServicio`, consola 9-10, pestaña Pedidos |
| RF14 | Resumen de ventas diarias | `CajaServicio`, `ResumenCaja`, consola 16, pestaña Caja |
| RNF01-09 | Validación de datos, clases organizadas, reutilización, pruebas y funcionalidad básica | Ver notas inferiores |

### Lo excluido intencionalmente

**RF06 — Combos** y **RF10 — Notificaciones internas** aparecen en la tabla de requisitos pero el **apartado 1 — Alcance del sistema** del PDF los excluye de forma explícita. Este programa sigue esa delimitación del alcance. Si el docente exige todo el listado de RF, habría que ajustar primero el alcance y agregar estos dos módulos.

## 3. Decisiones de negocio (documentadas)

- **En memoria:** todos los productos, pedidos y promociones desaparecen al cerrar la aplicación. No se utiliza BD.
- **Precios históricos:** cada línea del pedido guarda el nombre, descripción, cantidad y precio del momento. Cambiar o borrar productos no altera pedidos anteriores.
- **Promociones:** se consideran solo las activas y vigentes al momento de crear el pedido; si coinciden varias se aplica **únicamente la de mayor descuento**, sin acumularlas. En caso de empate gana la primera creada. El descuento queda congelado en el pedido.
- **Horarios:** la hora inicial es inclusiva y la final exclusiva. Los periodos que cruzan medianoche usan los días de inicio de la promoción (ejemplo: viernes 22:00 a sábado 02:00).
- **Dinero:** `BigDecimal`; los porcentajes se redondean al peso usando HALF_UP; el descuento no puede superar el subtotal.
- **Estados:** solo se puede avanzar una etapa. No hay retroceso ni entrega repetida.
- **Cierre de caja:** cuenta exclusivamente los pedidos **ENTREGADOS durante la fecha consultada**, y muestra la venta bruta, descuentos y venta neta. **No** es un arqueo físico de efectivo ni distingue medios de pago. Si un pedido se registró ayer pero se entregó hoy, cuenta hoy.
- **Complementos disponibles en ambas interfaces:** leche +$1.500, crema +$1.000, queso +$2.000. No es necesario un catálogo editable de complementos para el alcance actual.
- **La GUI es funcional pero provisional:** no se ha trabajado todavía el diseño visual UX. Los servicios no contienen código Swing ni lecturas de consola.

## 4. Ejemplo de prueba completa (consola)

1. Opción **12**: crear promoción `Descuento del día`; días `*` (todos); horario `00:00` a `23:59`; tipo `1` (porcentaje); porcentaje `10`.
2. Opción **1**: crear `Café`, `4500`, categoría `1` (bebida), descripción `Caliente`.
3. Opción **1**: crear `Arepa`, `6000`, categoría `2` (alimento), descripción `Con queso`.
4. Opción **8**: elegir ID `1` (Café), agregar **leche adicional** con opción `1`, finalizar personalización con `0`, cantidad `2`.
5. En el mismo pedido: elegir ID `2` (Arepa), terminar personalización con `0`, cantidad `1`.
6. Escribir `0` para confirmar: el **subtotal será $18.000**, descuento 10% **$1.800**, total **$16.200**.
7. Opción **9**: consultar el pedido. Opción **11**: avanzar el ID `1` tres veces hasta `Entregado`.
8. Opción **16**: dejar la fecha vacía para hoy. El resumen incluirá 1 pedido entregado, subtotal $18.000, descuentos $1.800 y ventas netas $16.200.
9. Salir con `0` hará que todo se pierda: esto **es intencional**.

En la interfaz Swing el flujo equivalente se encuentra en las pestañas **Promociones → Productos → Pedidos → Caja**.

## 5. Organización de paquetes y patrones

```text
src/main/java/co/edu/unilibre/cafeteria/
  consola/          AplicacionConsola (I/O por consola)
  grafica/          AplicacionGrafica (Swing provisional)
  modelo/           Producto, CategoriaProducto, ItemMenu, Complemento,
                    DetallePedido, Pedido, EstadoPedido, Promocion,
                    ResultadoDescuento, ResumenCaja
  promocion/        PoliticaDescuento, DescuentoPorcentaje, DescuentoFijo
  servicio/         ProductoServicio, PedidoServicio, PromocionServicio,
                    CajaServicio, ContextoCafeteria
src/test/java/co/edu/unilibre/cafeteria/
  modelo/           ComplementoTest
  servicio/         ProductoServicioTest, PedidoServicioTest,
                    PromocionServicioTest, CajaServicioTest
  pruebas/          VerificacionIntegrada (21 comprobaciones sin JUnit)
```

**Patrones aplicados:**

- **Decorator**: `ItemMenu` + `Complemento` para añadir ingredientes sin modificar `Producto`.
- **Strategy**: `PoliticaDescuento` con `DescuentoPorcentaje` y `DescuentoFijo`; es fácil añadir otras reglas.
- **Separación por capas**: las interfaces (consola/Swing) usan los mismos servicios y modelos. Los estados se manejan con una **máquina de estados en el enum** `EstadoPedido`; **no** se afirma que sea una implementación completa del patrón GoF State.

## 6. Verificaciones

- Código principal compilado con `javac --release 8 -encoding UTF-8`.
- Flujo real de consola ejecutado con una promoción, café personalizado, un pedido, entrega y resumen de caja.
- Ventana Swing lanzada correctamente en entorno gráfico de prueba.
- **21 verificaciones de integración** ejecutadas satisfactoriamente con `VerificacionIntegrada` (se puede ejecutar como clase Java desde NetBeans).
- **24 casos unitarios** comprobados mediante un ejecutor local compatible con las anotaciones y aserciones JUnit 4; los archivos de prueba reales usan JUnit 4 y quedan listos para `mvn test`.
- **Pruebas unitarias JUnit 4** incluidas para las funcionalidades principales. Se ejecutan con `mvn test` en NetBeans. La compilación Maven y la ejecución JUnit directa no pudieron comprobarse en el entorno de construcción porque no cuenta con el ejecutable `mvn`.

## 7. Posible continuación: diseño UX

Con la lógica funcional terminada, el siguiente trabajo es **rediseñar la interfaz de Swing**: mejorar distribución y navegación, usar tablas filtrables, formularios de edición, estados visuales y mensajes de confirmación. La arquitectura ya permite cambiar Swing sin alterar la lógica de negocio.
