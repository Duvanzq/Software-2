# Café & Co. — adaptación de Figma a Java Swing / Apache NetBeans

Proyecto de Ingeniería de Software II (Universidad Libre).  **Java 8 o superior**, **Maven**, **Swing**, **persistencia en memoria**.

## Diseño de referencia

Archivo Figma del usuario: https://www.figma.com/design/eyfhUH8rAQDfTdz7i94Lil/Caf%C3%A9---Co.-%C2%B7-Gesti%C3%B3n-de-cafeter%C3%ADa?node-id=0-1&m=dev

Se consultaron las pantallas **Inicio, Productos, Nuevo pedido, Pedidos, Promociones, Cierre de caja** y los diálogos del archivo Figma. Esta entrega los adapta con componentes Swing reales y los mismos servicios Java anteriores. Los colores base son espresso `#4D342A`, crema `#F7F0E8`, caramelo `#C98651` y verde salvia `#91A58D`. Los íconos y algunos diálogos están **simplificados** frente al diseño Figma original; el objetivo es una versión funcional y estilísticamente cercana, no una conversión pixel a pixel.

## Abrir y ejecutar en NetBeans

1. Descomprimir el `.zip` y entrar en la carpeta `Cafeteria_Java_Figma_NetBeans` (contiene `pom.xml`).
2. Apache NetBeans → **File > Open Project** → seleccionar esa carpeta.
3. Abrir `Source Packages > co.edu.unilibre.cafeteria.grafica > CafeteriaFigma.java`.
4. Clic derecho → **Run File** (`Shift + F6`) o ejecutar el proyecto como Maven. `pom.xml` configura `CafeteriaFigma` como clase principal.
5. Si Maven descarga las dependencias por primera vez, se necesita acceso a internet. Java 17 o 21 es apropiado, aunque el código compila con nivel de lenguaje Java 8.

### Importante sobre JFrame Form / `.form`

**Esta entrega es Swing codificado en Java (`CafeteriaFigma extends JFrame`) y se puede ejecutar/editar en NetBeans, pero NO incluye un `.form` nativo de GUI Builder.** Por eso NetBeans abrirá la pestaña **Source**, no el editor visual **Design** para esa clase. No es correcto renombrar el `.java` a `.form`: NetBeans emplea un formato propio para sus formularios. Si se requiere editar cada componente con arrastrar y soltar, la siguiente tarea es crear un `JFrame Form` desde NetBeans y migrar sus paneles de manera progresiva manteniendo los servicios y modelos ya incluidos.

## Pantallas y funciones

- **Inicio**: indicadores calculados desde pedidos reales, tabla de pedidos recientes y resumen de estados.
- **Productos**: registrar, buscar, filtrar, editar y eliminar con validaciones de entrada.
- **Nuevo pedido**: consultar catálogo, configurar cantidades y complementos, ver subtotal/descuento y registrar pedido.
- **Pedidos**: listar, filtrar, seleccionar pedido, consultar detalle y avanzar estado (pendiente → en preparación → listo → entregado).
- **Promociones**: crear descuentos por porcentaje o monto, elegir días y horarios, activar/desactivar y eliminar. La mayor promoción aplicable se calcula desde el servicio existente.
- **Cierre de caja**: seleccionar fecha de entrega y mostrar pedidos entregados, ventas brutas, descuentos y neto.

**Sin datos persistentes:** la aplicación inicia vacía. Para una demostración puedes registrar el producto “Latte artesanal”, `$9000`, bebida, y luego crear un pedido. El contenido se borra cuando termina la ejecución. En `docs/` se incluyen capturas obtenidas ejecutando la interfaz **con datos temporales de prueba**: no son datos reales ni quedan precargados en la aplicación.

**Alcance original:** se mantienen excluidos los combos y notificaciones internas, según apartado de alcance del PDF.

## Organización y patrones

- `grafica/CafeteriaFigma.java`: GUI rediseñada, Swing puro, pantalla central y eventos.
- `grafica/AplicacionGrafica.java`: GUI básica anterior, preservada para referencia.
- `consola/AplicacionConsola.java`: versión por consola preservada.
- `modelo/`: Producto, Complemento, Pedido, Promocion, etc.
- `servicio/`: servicios compartidos y almacenamiento en memoria.
- `promocion/`: Strategy para descuentos.
- `src/test/`: pruebas originales (JUnit y verificación de integración).

**Decorator** permite complementos sin cambiar `Producto`; **Strategy** para políticas de descuento; clases de servicio compartidas cumplen RNF07.

## Verificaciones realizadas

- Compilación de fuentes con `javac --release 8 -encoding UTF-8`.
- Creación de un contexto temporal de prueba y apertura de las seis pantallas sin excepciones bajo un servidor X virtual (Xvfb).
- Capturas de Inicio y Nuevo pedido hechas con `JFrame.paintAll` usando datos temporales.
- El diseño se comprobó a **1440 × 900**. En tamaños menores, los paneles se comprimen y/o desplazan con scroll cuando sea necesario.
- **Pendiente de verificar en el computador del usuario:** ejecución desde NetBeans en Windows, interacción manual de los cuadros de diálogo y `mvn test` nativo (Maven CLI no disponible en la herramienta de construcción).

No se han modificado los archivos del diseño de Figma; solo se creó una adaptación en el código Java.
