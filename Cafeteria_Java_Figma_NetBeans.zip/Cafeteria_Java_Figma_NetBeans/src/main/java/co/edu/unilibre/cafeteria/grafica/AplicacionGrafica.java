package co.edu.unilibre.cafeteria.grafica;

import co.edu.unilibre.cafeteria.modelo.CategoriaProducto;
import co.edu.unilibre.cafeteria.modelo.Complemento;
import co.edu.unilibre.cafeteria.modelo.DetallePedido;
import co.edu.unilibre.cafeteria.modelo.ItemMenu;
import co.edu.unilibre.cafeteria.modelo.Pedido;
import co.edu.unilibre.cafeteria.modelo.Producto;
import co.edu.unilibre.cafeteria.modelo.Promocion;
import co.edu.unilibre.cafeteria.modelo.ResumenCaja;
import co.edu.unilibre.cafeteria.promocion.DescuentoFijo;
import co.edu.unilibre.cafeteria.promocion.DescuentoPorcentaje;
import co.edu.unilibre.cafeteria.promocion.PoliticaDescuento;
import co.edu.unilibre.cafeteria.servicio.ContextoCafeteria;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Interfaz Swing FUNCIONAL provisional. El diseño UX puede cambiar sin tocar
 * los servicios compartidos con la aplicación de consola.
 */
public final class AplicacionGrafica extends JFrame {
    private final ContextoCafeteria contexto;
    private final JTextArea vistaProductos = area();
    private final JTextArea vistaPedidos = area();
    private final JTextArea vistaPromociones = area();
    private final JTextArea vistaCaja = area();
    private final NumberFormat pesos = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));
    private final DateTimeFormatter fechaHora = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public AplicacionGrafica() { this(new ContextoCafeteria()); }

    public AplicacionGrafica(ContextoCafeteria contexto) {
        super("Cafetería - Ingeniería de Software II");
        this.contexto = contexto;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(920, 570);
        setLocationRelativeTo(null);
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Productos", panel(vistaProductos,
                boton("Agregar", () -> agregarProducto()),
                boton("Editar", () -> editarProducto()),
                boton("Eliminar", () -> eliminarProducto()),
                boton("Actualizar", () -> actualizarTodo())));
        tabs.addTab("Pedidos", panel(vistaPedidos,
                boton("Nuevo pedido", () -> crearPedido()),
                boton("Ver detalle", () -> verPedido()),
                boton("Avanzar estado", () -> avanzarPedido()),
                boton("Actualizar", () -> actualizarTodo())));
        tabs.addTab("Promociones", panel(vistaPromociones,
                boton("Nueva promoción", () -> agregarPromocion()),
                boton("Activar / Desactivar", () -> alternarPromocion()),
                boton("Eliminar", () -> eliminarPromocion()),
                boton("Actualizar", () -> actualizarTodo())));
        tabs.addTab("Caja", panel(vistaCaja,
                boton("Resumen de hoy", () -> mostrarCaja(LocalDate.now(contexto.getReloj()))),
                boton("Buscar fecha", () -> elegirFecha())));
        add(tabs);
        actualizarTodo();
        mostrarCaja(LocalDate.now(contexto.getReloj()));
    }

    private JTextArea area() {
        JTextArea t = new JTextArea();
        t.setEditable(false);
        t.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        t.setLineWrap(true);
        t.setWrapStyleWord(true);
        return t;
    }

    private JButton boton(String texto, Runnable accion) {
        JButton b = new JButton(texto);
        b.addActionListener(e -> {
            try {
                accion.run();
                actualizarTodo();
            } catch (Cancelado e2) {
                // Se presionó Cancelar: no cambiar el sistema.
            } catch (RuntimeException e2) {
                JOptionPane.showMessageDialog(this, e2.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
            }
        });
        return b;
    }

    private JPanel panel(JTextArea area, JButton... botones) {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JPanel herramientas = new JPanel(new FlowLayout(FlowLayout.LEFT));
        for (JButton boton : botones) herramientas.add(boton);
        panel.add(herramientas, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        return panel;
    }

    private String pedir(String mensaje) {
        String valor = JOptionPane.showInputDialog(this, mensaje);
        if (valor == null) throw new Cancelado();
        if (valor.trim().isEmpty()) throw new IllegalArgumentException("No puedes dejar este campo vacío.");
        return valor.trim();
    }

    private String opcional(String mensaje, String anterior) {
        String texto = JOptionPane.showInputDialog(this, mensaje, anterior);
        if (texto == null) throw new Cancelado();
        return texto.trim().isEmpty() ? anterior : texto.trim();
    }

    private int positivo(String mensaje) {
        try {
            int numero = Integer.parseInt(pedir(mensaje));
            if (numero > 0) return numero;
        } catch (NumberFormatException e) {
            // Mismo mensaje de validación.
        }
        throw new IllegalArgumentException("Ingresa un entero positivo.");
    }

    private BigDecimal decimal(String mensaje) {
        try {
            BigDecimal valor = new BigDecimal(pedir(mensaje).replace(',', '.'));
            if (valor.signum() > 0) return valor;
        } catch (NumberFormatException e) {
            // Mismo mensaje de validación.
        }
        throw new IllegalArgumentException("Ingresa un número mayor que cero, sin separadores de miles.");
    }

    private CategoriaProducto categoria(String mensaje, CategoriaProducto actual) {
        CategoriaProducto seleccion = (CategoriaProducto) JOptionPane.showInputDialog(this,
                mensaje, "Categoría", JOptionPane.QUESTION_MESSAGE, null,
                CategoriaProducto.values(), actual);
        if (seleccion == null) throw new Cancelado();
        return seleccion;
    }

    private void agregarProducto() {
        String nombre = pedir("Nombre del producto:");
        BigDecimal precio = decimal("Precio en COP:");
        CategoriaProducto cat = categoria("Categoría:", CategoriaProducto.BEBIDA);
        String descripcion = pedir("Descripción:");
        Producto p = contexto.getProductos().registrar(nombre, precio, cat, descripcion);
        avisar("Producto #" + p.getId() + " creado.");
    }

    private void editarProducto() {
        Producto p = contexto.getProductos().buscarPorId(positivo("ID del producto a editar:"));
        String nombre = opcional("Nombre:", p.getNombre());
        BigDecimal precio = new BigDecimal(opcional("Precio (COP):", p.getPrecio().toPlainString()).replace(',', '.'));
        CategoriaProducto cat = categoria("Categoría:", p.getCategoria());
        String descripcion = opcional("Descripción:", p.getDescripcion());
        contexto.getProductos().editar(p.getId(), nombre, precio, cat, descripcion);
        avisar("Producto actualizado.");
    }

    private void eliminarProducto() {
        Producto p = contexto.getProductos().buscarPorId(positivo("ID para eliminar:"));
        if (confirmar("¿Eliminar " + p.getNombre() + "?")) {
            contexto.getProductos().eliminar(p.getId());
            avisar("Producto eliminado.");
        }
    }

    private ItemMenu personalizar(Producto producto) {
        Deque<ItemMenu> versiones = new ArrayDeque<ItemMenu>();
        versiones.push(producto);
        while (true) {
            String[] opciones = {"Terminar", "Leche adicional (+1500)", "Crema (+1000)",
                                 "Queso (+2000)", "Quitar último complemento"};
            int respuesta = JOptionPane.showOptionDialog(this,
                    producto.getNombre() + "\n" + versiones.peek().getDescripcion()
                    + "\nPrecio unitario: " + pesos.format(versiones.peek().getPrecio()),
                    "Personalización (Decorator)", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            switch (respuesta) {
                case 0: return versiones.peek();
                case 1: versiones.push(new Complemento(versiones.peek(), "Leche adicional", new BigDecimal("1500"))); break;
                case 2: versiones.push(new Complemento(versiones.peek(), "Crema", new BigDecimal("1000"))); break;
                case 3: versiones.push(new Complemento(versiones.peek(), "Queso", new BigDecimal("2000"))); break;
                case 4: if (versiones.size() > 1) versiones.pop(); break;
                default: throw new Cancelado();
            }
        }
    }

    private void crearPedido() {
        if (contexto.getProductos().listar().isEmpty())
            throw new IllegalArgumentException("Primero registra un producto en la pestaña Productos.");
        List<DetallePedido> detalles = new ArrayList<DetallePedido>();
        while (true) {
            StringBuilder catalogo = new StringBuilder("PRODUCTOS DISPONIBLES\n");
            for (Producto p : contexto.getProductos().listar())
                catalogo.append("#").append(p.getId()).append(" - ").append(p.getNombre())
                        .append(" - ").append(pesos.format(p.getPrecio())).append("\n");
            catalogo.append("\nProductos agregados: ").append(detalles.size());
            catalogo.append("\nID del siguiente producto (0 para terminar):");
            String opcion = pedir(catalogo.toString());
            final int id;
            try { id = Integer.parseInt(opcion); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("ID inválido."); }
            if (id == 0) break;
            Producto p = contexto.getProductos().buscarPorId(id);
            ItemMenu personalizado = personalizar(p);
            int cantidad = positivo("Cantidad de " + p.getNombre() + ":");
            detalles.add(new DetallePedido(p.getNombre(), personalizado, cantidad));
        }
        if (detalles.isEmpty()) throw new IllegalArgumentException("Agrega al menos un producto.");
        BigDecimal bruto = BigDecimal.ZERO;
        for (DetallePedido d : detalles) bruto = bruto.add(d.getSubtotal());
        if (confirmar("¿Guardar pedido con " + detalles.size()
                + " líneas?\nSubtotal antes de promociones: " + pesos.format(bruto)
                + "\n(El mejor descuento vigente se aplicará automáticamente)")) {
            Pedido pedido = contexto.getPedidos().registrar(detalles);
            avisar("Pedido #" + pedido.getId() + " creado.\n" + textoPedido(pedido));
        }
    }

    private String textoPedido(Pedido pedido) {
        StringBuilder s = new StringBuilder();
        s.append("Pedido #").append(pedido.getId()).append(" | ").append(pedido.getEstado())
                .append(" | ").append(fechaHora.format(pedido.getFecha())).append("\n");
        for (DetallePedido d : pedido.getDetalles()) {
            s.append("  ").append(d.getCantidad()).append(" x ").append(d.getNombreProducto())
                    .append(" - ").append(d.getDescripcion()).append(" - ")
                    .append(pesos.format(d.getSubtotal())).append("\n");
        }
        s.append("Subtotal: ").append(pesos.format(pedido.getSubtotal())).append("\n")
                .append("Promoción: ").append(pedido.getNombrePromocion()).append("\n")
                .append("Descuento: ").append(pesos.format(pedido.getDescuento())).append("\n")
                .append("TOTAL: ").append(pesos.format(pedido.getTotal()));
        if (pedido.getFechaEntrega() != null)
            s.append("\nEntregado: ").append(fechaHora.format(pedido.getFechaEntrega()));
        return s.toString();
    }

    private void verPedido() {
        avisar(textoPedido(contexto.getPedidos().buscarPorId(positivo("ID del pedido:"))));
    }

    private void avanzarPedido() {
        Pedido pedido = contexto.getPedidos().avanzarEstado(positivo("ID del pedido a avanzar:"));
        avisar("Nuevo estado: " + pedido.getEstado());
    }

    private Set<DayOfWeek> parsearDias(String texto) {
        if ("*".equals(texto)) return EnumSet.allOf(DayOfWeek.class);
        EnumSet<DayOfWeek> dias = EnumSet.noneOf(DayOfWeek.class);
        try {
            for (String parte : texto.split(",")) dias.add(DayOfWeek.of(Integer.parseInt(parte.trim())));
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("Días: números del 1 (lunes) al 7 (domingo), o *.");
        }
        if (dias.isEmpty()) throw new IllegalArgumentException("Elige por lo menos un día.");
        return dias;
    }

    private LocalTime hora(String mensaje) {
        try { return LocalTime.parse(pedir(mensaje)); }
        catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException("La hora debe tener formato HH:mm.");
        }
    }

    private void agregarPromocion() {
        String nombre = pedir("Nombre de la promoción:");
        Set<DayOfWeek> dias = parsearDias(pedir("Días: 1=lunes ... 7=domingo; 1,3,5; o * todos:"));
        LocalTime inicio = hora("Hora de inicio HH:mm:");
        LocalTime fin = hora("Hora de fin HH:mm (puede cruzar medianoche):");
        String tipo = pedir("Tipo: 1=porcentaje, 2=monto fijo COP:");
        PoliticaDescuento regla;
        if ("1".equals(tipo)) regla = new DescuentoPorcentaje(decimal("Porcentaje de descuento:"));
        else if ("2".equals(tipo)) regla = new DescuentoFijo(decimal("Monto de descuento COP:"));
        else throw new IllegalArgumentException("Tipo: escribe 1 o 2.");
        Promocion p = contexto.getPromociones().registrar(nombre, dias, inicio, fin, regla);
        avisar("Promoción #" + p.getId() + " creada.");
    }

    private void alternarPromocion() {
        Promocion p = contexto.getPromociones().buscarPorId(positivo("ID de promoción:"));
        contexto.getPromociones().cambiarActiva(p.getId(), !p.isActiva());
        avisar("La promoción está " + (p.isActiva() ? "activa" : "inactiva") + ".");
    }

    private void eliminarPromocion() {
        int id = positivo("ID de promoción a eliminar:");
        if (confirmar("¿Eliminar la promoción #" + id + "?")) {
            contexto.getPromociones().eliminar(id);
            avisar("Promoción eliminada.");
        }
    }

    private void elegirFecha() {
        LocalDate fecha;
        try { fecha = LocalDate.parse(pedir("Fecha del cierre (AAAA-MM-DD):")); }
        catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException("Fecha inválida. Usa AAAA-MM-DD.");
        }
        mostrarCaja(fecha);
    }

    private void mostrarCaja(LocalDate fecha) {
        ResumenCaja r = contexto.getCaja().resumir(fecha);
        vistaCaja.setText("===== CIERRE DE CAJA " + r.getFecha() + " =====\n\n"
                + "Pedidos entregados: " + r.getPedidosEntregados() + "\n"
                + "Ventas brutas: " + pesos.format(r.getSubtotalBruto()) + "\n"
                + "Descuentos aplicados: " + pesos.format(r.getDescuentos()) + "\n"
                + "VENTAS NETAS: " + pesos.format(r.getVentasNetas()) + "\n\n"
                + "Solo se cuentan pedidos ENTREGADOS en el día de su entrega.\n"
                + "Este es un resumen, no un arqueo físico de efectivo.\n");
    }

    private void actualizarTodo() {
        StringBuilder productos = new StringBuilder("PRODUCTOS DEL MENÚ\n\n");
        for (Producto p : contexto.getProductos().listar()) {
            productos.append("#").append(p.getId()).append("  ").append(p.getNombre())
                    .append("  | ").append(p.getCategoria()).append("  | ")
                    .append(pesos.format(p.getPrecio())).append("\n    ")
                    .append(p.getDescripcion()).append("\n\n");
        }
        if (contexto.getProductos().listar().isEmpty()) productos.append("Sin productos registrados.");
        vistaProductos.setText(productos.toString());

        StringBuilder pedidos = new StringBuilder("PEDIDOS\n\n");
        for (Pedido p : contexto.getPedidos().listar()) {
            pedidos.append("#").append(p.getId()).append(" | ").append(fechaHora.format(p.getFecha()))
                    .append(" | ").append(p.getEstado()).append(" | ")
                    .append(pesos.format(p.getTotal())).append("\n");
        }
        if (contexto.getPedidos().listar().isEmpty()) pedidos.append("Sin pedidos registrados.");
        vistaPedidos.setText(pedidos.toString());

        StringBuilder promociones = new StringBuilder("PROMOCIONES (solo se aplica la de mayor ahorro)\n\n");
        for (Promocion p : contexto.getPromociones().listar()) {
            promociones.append("#").append(p.getId()).append(" ").append(p.getNombre())
                    .append(" | ").append(p.isActiva() ? "ACTIVA" : "INACTIVA")
                    .append(" | ").append(p.getRegla()).append("\n    Días: ")
                    .append(p.getDias()).append(" | Horario: ").append(p.getInicio())
                    .append(" - ").append(p.getFin()).append("\n\n");
        }
        if (contexto.getPromociones().listar().isEmpty()) promociones.append("Sin promociones registradas.");
        vistaPromociones.setText(promociones.toString());
    }

    private boolean confirmar(String mensaje) {
        return JOptionPane.showConfirmDialog(this, mensaje, "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    private void avisar(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    private static final class Cancelado extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { /* Utiliza el tema básico de Java. */ }
            new AplicacionGrafica().setVisible(true);
        });
    }
}
